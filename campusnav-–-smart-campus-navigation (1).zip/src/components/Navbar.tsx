import React from 'react';
import {
  Navigation,
  QrCode,
  Radio,
  Settings,
  HelpCircle,
  MapPin,
  Compass,
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';

interface NavbarProps {
  onOpenQRScanner: () => void;
  onOpenPositioningModal: () => void;
  isAdminOpen: boolean;
  onToggleAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenQRScanner,
  onOpenPositioningModal,
  isAdminOpen,
  onToggleAdmin,
}) => {
  const { userPosition, gpsTrackingActive } = useCampus();

  const getPositioningBadge = () => {
    switch (userPosition.method) {
      case 'qr':
        return {
          label: 'QR Verified (Precise)',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          dot: 'bg-emerald-500',
        };
      case 'ble':
        return {
          label: 'BLE Beacon (Indoor)',
          bg: 'bg-purple-50 text-purple-700 border-purple-200',
          dot: 'bg-purple-500',
        };
      case 'gps':
        return {
          label: gpsTrackingActive ? 'Live GPS Tracking' : 'GPS Outdoors',
          bg: 'bg-blue-50 text-blue-700 border-blue-200',
          dot: 'bg-blue-500',
        };
      case 'simulated':
        return {
          label: 'Simulated Walk',
          bg: 'bg-amber-50 text-amber-700 border-amber-200',
          dot: 'bg-amber-500',
        };
      default:
        return {
          label: 'Manual Pin',
          bg: 'bg-slate-50 text-slate-700 border-slate-200',
          dot: 'bg-slate-400',
        };
    }
  };

  const badge = getPositioningBadge();

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs px-3 sm:px-6 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        {/* Brand / Logo */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Compass className="w-5 h-5 sm:w-6 sm:h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900">
                Campus<span className="text-blue-600">Nav</span>
              </span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-sm bg-blue-100 text-blue-800">
                Indoor & Outdoor
              </span>
            </div>
            <p className="text-[11px] text-slate-500 hidden sm:block">
              Never Get Lost on Campus Again
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Positioning mode button */}
          <button
            onClick={onOpenPositioningModal}
            className={`hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-xs font-semibold cursor-pointer transition-all hover:shadow-xs ${badge.bg}`}
            title="Click to inspect positioning technology"
          >
            <span className={`w-2 h-2 rounded-full ${badge.dot} animate-pulse`} />
            <span>{badge.label}</span>
            <span className="text-[10px] opacity-70">±{userPosition.accuracyMeters}m</span>
          </button>

          {/* Scan QR Checkpoint Button */}
          <button
            onClick={onOpenQRScanner}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold transition-colors cursor-pointer border border-slate-200"
            title="Scan indoor QR code checkpoint"
          >
            <QrCode className="w-4 h-4 text-blue-600" />
            <span className="hidden xs:inline">Scan QR Checkpoint</span>
          </button>

          {/* Admin Dashboard Toggle */}
          <button
            onClick={onToggleAdmin}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
              isAdminOpen
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span className="hidden sm:inline">
              {isAdminOpen ? 'Close Admin' : 'Campus Admin'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
