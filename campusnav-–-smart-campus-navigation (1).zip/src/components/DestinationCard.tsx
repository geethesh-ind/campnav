import React, { useMemo, useState } from 'react';
import {
  Navigation,
  X,
  Clock,
  Mail,
  Share2,
  Building2,
  Sparkles,
  MapPin,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { findOptimalPath } from '../utils/navigationEngine';

export const DestinationCard: React.FC = () => {
  const {
    selectedDestination,
    setSelectedDestination,
    startNavigation,
    startLocation,
    setStartLocation,
    isNavigating,
    userPosition,
    buildings,
    floors,
    locations,
    nodes,
    connections,
    routingPreference,
  } = useCampus();

  const [copied, setCopied] = useState(false);

  const building = useMemo(
    () => (selectedDestination ? buildings.find(b => b.id === selectedDestination.buildingId) : undefined),
    [buildings, selectedDestination]
  );
  const floor = useMemo(
    () => (selectedDestination ? floors.find(f => f.id === selectedDestination.floorId) : undefined),
    [floors, selectedDestination]
  );

  // Calculate distance & time preview from selected start location or nearest node to userPosition
  const routePreview = useMemo(() => {
    if (!selectedDestination || nodes.length === 0) {
      return { distance: 0, time: 1, reachable: true };
    }

    let startNodeId = startLocation?.associatedNodeId;
    if (!startNodeId) {
      const sameFloorNodes = nodes.filter(
        n => n.floorId === userPosition.floorId && n.buildingId === userPosition.buildingId
      );
      const candidates = sameFloorNodes.length > 0 ? sameFloorNodes : nodes;
      let closestNode = candidates[0];
      let minDist = Infinity;
      for (const n of candidates) {
        const d = Math.hypot(n.x - userPosition.x, n.y - userPosition.y);
        if (d < minDist) {
          minDist = d;
          closestNode = n;
        }
      }
      startNodeId = closestNode.id;
    }

    const path = findOptimalPath(
      startNodeId,
      selectedDestination.associatedNodeId,
      nodes,
      connections,
      routingPreference
    );

    if (!path) {
      return { distance: 0, time: 0, reachable: false };
    }

    return {
      distance: path.totalDistanceMeters,
      time: Math.max(1, Math.ceil(path.totalDistanceMeters / 60)),
      reachable: true,
    };
  }, [userPosition, startLocation, selectedDestination, nodes, connections, routingPreference]);

  if (!selectedDestination || isNavigating) {
    return null;
  }

  const handleShare = () => {
    const text = `Find ${selectedDestination.name} (${selectedDestination.roomNumber}) in ${building?.name || 'Campus'}, ${floor?.floorName || 'Ground Floor'} on CampusNav!`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).catch(() => {});
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed bottom-4 left-0 right-0 z-20 pointer-events-none px-3">
      <div className="max-w-xl mx-auto pointer-events-auto">
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 transition-all animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header Info */}
          <div className="p-4 sm:p-5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 text-[11px] font-mono font-extrabold uppercase">
                    {selectedDestination.roomNumber}
                  </span>
                  <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    {selectedDestination.category.replace('_', ' ')}
                  </span>
                </div>
                <h3 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight leading-snug">
                  {selectedDestination.name}
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 mt-1 flex items-center gap-1.5 font-medium">
                  <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span className="truncate">{building?.name || 'Campus Grounds'}</span>
                  <span>•</span>
                  <span className="shrink-0">{floor?.floorName || 'Outdoor Grounds'}</span>
                </p>
              </div>

              <button
                onClick={() => setSelectedDestination(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors shrink-0"
                aria-label="Close destination details"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 mt-2.5 leading-relaxed">
              {selectedDestination.description}
            </p>

            {/* Starting point selector */}
            <div className="mt-3 flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5">
              <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              <label htmlFor="dest-start-select" className="text-[11px] font-bold text-slate-500 uppercase tracking-wide shrink-0">
                Start:
              </label>
              <select
                id="dest-start-select"
                value={startLocation?.id || ''}
                onChange={e => {
                  const chosen = locations.find(l => l.id === e.target.value) || null;
                  setStartLocation(chosen);
                }}
                className="w-full text-xs font-semibold text-slate-800 bg-transparent focus:outline-hidden cursor-pointer truncate"
              >
                <option value="">
                  Current Location ({userPosition.confirmedLocationName || 'Campus Map Pin'})
                </option>
                {locations
                  .filter(l => l.id !== selectedDestination.id)
                  .map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} ({loc.roomNumber})
                    </option>
                  ))}
              </select>
            </div>

            {/* Faculty Details if available */}
            {selectedDestination.facultyInfo && (
              <div className="mt-3 p-3 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs text-slate-700">
                <div className="flex items-center gap-2 mb-1 text-blue-900 font-bold">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>Faculty & Department Profile</span>
                </div>
                <p className="font-bold text-slate-900 text-sm">
                  {selectedDestination.facultyInfo.name}
                </p>
                <p className="text-slate-600 font-medium">
                  {selectedDestination.facultyInfo.designation} • {selectedDestination.facultyInfo.department}
                </p>
                <div className="mt-2 pt-2 border-t border-blue-200/50 flex flex-wrap gap-x-4 gap-y-1 text-slate-600">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-blue-600" />
                    <span>Office Hours: {selectedDestination.facultyInfo.officeHours}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Mail className="w-3 h-3 text-blue-600" />
                    <span>{selectedDestination.facultyInfo.email}</span>
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons & Distance metrics */}
          <div className="p-3 sm:p-4 bg-slate-50 flex items-center justify-between gap-3">
            {routePreview.reachable ? (
              <div className="flex items-baseline gap-1.5 text-xs">
                <span className="text-lg font-extrabold text-slate-900">
                  {routePreview.distance}m
                </span>
                <span className="text-slate-500 font-medium">
                  (~{routePreview.time} min walk)
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-xs text-amber-700 font-semibold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>No elevator path in wheelchair mode (stairs only)</span>
              </div>
            )}

            <div className="flex items-center gap-2 shrink-0">
              <button
                onClick={handleShare}
                className="px-2.5 py-2.5 rounded-xl bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 shadow-2xs transition-colors cursor-pointer flex items-center gap-1 text-xs font-semibold"
                title="Copy location link"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
                {copied && <span className="text-emerald-700">Copied</span>}
              </button>

              <button
                onClick={() => startNavigation(selectedDestination, startLocation || undefined)}
                disabled={!routePreview.reachable}
                className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-sm flex items-center gap-2 shadow-md shadow-blue-500/20 transition-all cursor-pointer"
              >
                <Navigation className="w-4 h-4" />
                <span>Start Navigation</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

