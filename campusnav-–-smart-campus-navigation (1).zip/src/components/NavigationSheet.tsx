import React from 'react';
import {
  Navigation,
  ArrowUp,
  ArrowUpRight,
  ArrowUpLeft,
  CornerUpRight,
  CornerUpLeft,
  ChevronsUpDown,
  CheckCircle2,
  AlertTriangle,
  Play,
  Pause,
  SkipForward,
  RotateCcw,
  Footprints,
  Compass,
  X,
  Volume2,
  Accessibility,
  Zap,
} from 'lucide-react';
import { StairsIcon } from './icons/StairsIcon';
import { useCampus } from '../context/CampusContext';
import { RoutingPreference } from '../types/campus';

export const NavigationSheet: React.FC = () => {
  const {
    isNavigating,
    activeRoute,
    currentStepIndex,
    stopNavigation,
    stepForward,
    stepBackward,
    isSimulatingWalk,
    toggleSimulation,
    simulationSpeed,
    setSimulationSpeed,
    simulateWrongTurn,
    recalculateRoute,
    wrongDirectionStatus,
    routingPreference,
    setRoutingPreference,
    userPosition,
    floors,
    buildings,
  } = useCampus();

  if (!isNavigating || !activeRoute) {
    return null;
  }

  const currentStep = activeRoute.steps[currentStepIndex] || activeRoute.steps[0];
  const nextStep = activeRoute.steps[currentStepIndex + 1];

  // Current floor & building names
  const currentFloorObj = floors.find(f => f.id === userPosition.floorId);
  const currentBuildingObj = buildings.find(b => b.id === userPosition.buildingId);
  const destinationFloorObj = floors.find(f => f.id === activeRoute.destinationLocation.floorId);
  const destinationBuildingObj = buildings.find(b => b.id === activeRoute.destinationLocation.buildingId);

  // Remaining distance & time calculation from current step onward
  const remainingDistance = activeRoute.steps
    .slice(currentStepIndex)
    .reduce((acc, step) => acc + step.distanceMeters, 0);

  const remainingSeconds = activeRoute.steps
    .slice(currentStepIndex)
    .reduce((acc, step) => acc + step.estimatedSeconds, 0);

  const remainingMinutes = Math.max(1, Math.ceil(remainingSeconds / 60));

  // Step Icon
  const getStepIcon = (action: string) => {
    switch (action) {
      case 'turn_left':
        return <CornerUpLeft className="w-8 h-8 text-white" />;
      case 'turn_right':
        return <CornerUpRight className="w-8 h-8 text-white" />;
      case 'staircase_up':
      case 'staircase_down':
        return <StairsIcon className="w-8 h-8 text-white" />;
      case 'elevator_up':
      case 'elevator_down':
        return <ChevronsUpDown className="w-8 h-8 text-white" />;
      case 'arrive':
        return <CheckCircle2 className="w-8 h-8 text-white" />;
      default:
        return <ArrowUp className="w-8 h-8 text-white" />;
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-30 pointer-events-none">
      <div className="max-w-xl mx-auto p-3 pointer-events-auto">
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden divide-y divide-slate-100 transition-all">
          {/* 1. WRONG DIRECTION BANNER ALERT */}
          {wrongDirectionStatus?.isWrongDirection && (
            <div className="bg-rose-600 text-white p-3.5 px-4 flex items-center justify-between animate-pulse">
              <div className="flex items-center gap-2.5">
                <div className="p-1.5 bg-rose-700/80 rounded-xl">
                  <AlertTriangle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h4 className="text-sm font-bold tracking-tight">
                    You are going in the wrong direction!
                  </h4>
                  <p className="text-xs text-rose-100">
                    {wrongDirectionStatus.message}
                  </p>
                </div>
              </div>

              <button
                onClick={recalculateRoute}
                className="px-3 py-1.5 rounded-lg bg-white text-rose-700 font-bold text-xs shadow-xs hover:bg-rose-50 transition-colors cursor-pointer"
              >
                Recalculate
              </button>
            </div>
          )}

          {/* 2. MAIN TURN-BY-TURN GUIDANCE BANNER */}
          <div className="bg-blue-600 text-white p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs text-blue-100 font-semibold uppercase tracking-wider">
                <Navigation className="w-3.5 h-3.5" />
                <span>Destination: {activeRoute.destinationLocationName}</span>
              </div>
              <button
                onClick={stopNavigation}
                className="w-7 h-7 rounded-full bg-blue-700/70 hover:bg-blue-800 flex items-center justify-center text-white text-xs cursor-pointer transition-colors"
                title="End navigation"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Big Instruction and Direction Icon */}
            <div className="flex items-start gap-3.5 my-1">
              <div className="w-13 h-13 rounded-2xl bg-blue-700/80 border border-blue-400/30 flex items-center justify-center shrink-0 shadow-inner">
                {getStepIcon(currentStep.action)}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg sm:text-xl font-extrabold leading-snug">
                  {currentStep.primaryText}
                </h3>
                {currentStep.secondaryText && (
                  <p className="text-xs text-blue-100 font-medium mt-0.5">
                    {currentStep.secondaryText}
                  </p>
                )}
              </div>
            </div>

            {/* Then instruction preview */}
            {nextStep && (
              <div className="mt-3 pt-2.5 border-t border-blue-500/40 flex items-center gap-2 text-xs text-blue-100 font-medium">
                <span className="font-bold uppercase tracking-wider text-[10px] bg-blue-700 px-1.5 py-0.5 rounded">
                  Then
                </span>
                <span className="truncate">{nextStep.primaryText}</span>
              </div>
            )}
          </div>

          {/* 3. METRIC STATS & LOCATION PILLS */}
          <div className="p-3.5 bg-slate-50 flex items-center justify-between text-xs">
            <div className="flex items-baseline gap-2">
              <span className="text-xl font-extrabold text-slate-900">
                {remainingMinutes} <span className="text-xs font-semibold text-slate-500">min</span>
              </span>
              <span className="text-slate-400">•</span>
              <span className="font-bold text-slate-700">{remainingDistance} metres</span>
            </div>

            {/* Location Indicators */}
            <div className="flex items-center gap-1.5">
              <span className="px-2 py-0.8 rounded-md bg-white border border-slate-200 text-slate-700 font-semibold text-[11px]">
                {currentBuildingObj?.code || 'Campus'} • {currentFloorObj?.code || 'G'}
              </span>
              <span className="text-slate-400">→</span>
              <span className="px-2 py-0.8 rounded-md bg-blue-50 border border-blue-200 text-blue-700 font-bold text-[11px]">
                {destinationBuildingObj?.code || 'Campus'} • {destinationFloorObj?.code || 'G'}
              </span>
            </div>
          </div>

          {/* 4. ROUTE PREFERENCE PICKER */}
          <div className="px-3.5 py-2 flex items-center justify-between gap-1.5 overflow-x-auto text-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              Route:
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setRoutingPreference('shortest')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-1 ${
                  routingPreference === 'shortest'
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                <Zap className="w-3 h-3" />
                <span>Shortest</span>
              </button>
              <button
                onClick={() => setRoutingPreference('fewer_stairs')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-1 ${
                  routingPreference === 'fewer_stairs'
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                <StairsIcon className="w-3 h-3" />
                <span>Fewer Stairs</span>
              </button>
              <button
                onClick={() => setRoutingPreference('wheelchair')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-all cursor-pointer flex items-center gap-1 ${
                  routingPreference === 'wheelchair'
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                <Accessibility className="w-3 h-3" />
                <span>Wheelchair</span>
              </button>
            </div>
          </div>

          {/* 5. WALKING SIMULATION & DEV TEST TOOLBAR */}
          <div className="p-3 bg-white flex flex-wrap items-center justify-between gap-2 text-xs">
            {/* Simulation controls */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={toggleSimulation}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                  isSimulatingWalk
                    ? 'bg-amber-500 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
                title="Simulate student walking along route"
              >
                {isSimulatingWalk ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                <span>{isSimulatingWalk ? 'Pause Walk' : 'Simulate Walk'}</span>
              </button>

              <button
                onClick={stepForward}
                disabled={currentStepIndex >= activeRoute.steps.length - 1}
                className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 cursor-pointer"
                title="Step forward to next waypoint"
              >
                <SkipForward className="w-4 h-4" />
              </button>

              {/* Speed dropdown */}
              <div className="flex items-center bg-slate-100 rounded-lg p-0.5">
                {[1, 2, 5].map(spd => (
                  <button
                    key={spd}
                    onClick={() => setSimulationSpeed(spd)}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-bold cursor-pointer ${
                      simulationSpeed === spd ? 'bg-white text-blue-600 shadow-2xs' : 'text-slate-500'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>

            {/* Test Wrong Turn Button */}
            <button
              onClick={simulateWrongTurn}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold border border-rose-200 transition-colors cursor-pointer"
              title="Test Wrong-Direction Warning & Automatic Recalculation"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
              <span>Simulate Wrong Turn</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
