import React from 'react';
import {
  Compass,
  X,
  Radio,
  QrCode,
  MapPin,
  Wifi,
  Navigation,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Cpu,
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';

interface PositioningModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PositioningModal: React.FC<PositioningModalProps> = ({ isOpen, onClose }) => {
  const {
    userPosition,
    requestRealGPS,
    startLiveGPSTracking,
    stopLiveGPSTracking,
    gpsTrackingActive,
    gpsError,
    liveGpsCoords,
    simulateBLEScan,
    beacons,
  } = useCampus();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                Positioning System Architecture
              </h3>
              <p className="text-xs text-slate-500">
                Indoor vs Outdoor Positioning Infrastructure & Limitations
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Active Mode Banner */}
        <div className="bg-slate-50 px-5 py-3 border-b border-slate-100 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-500 font-medium">Active Position: </span>
            <span className="font-bold text-slate-800">
              {userPosition.confirmedLocationName || 'Campus Grounds'}
            </span>
          </div>
          <div className="flex items-center gap-1.5 font-bold text-blue-700 bg-blue-100/80 px-2.5 py-1 rounded-full">
            <span>±{userPosition.accuracyMeters}m accuracy</span>
          </div>
        </div>

        {/* Body content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">
          {/* Overview Note */}
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200/80 text-amber-900 text-xs leading-relaxed">
            <div className="flex items-center gap-1.5 font-bold mb-1">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>Physical Hardware Notice</span>
            </div>
            Modern mobile web browsers lack the native hardware APIs to penetrate reinforced concrete slabs or discriminate vertical altitude (Z-axis) across university floors. CampusNav implements a modular positioning system combining outdoor GPS, corridor BLE beacons, and high-precision QR ground-truth checkpoints.
          </div>

          {/* 1. Outdoor GPS */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 transition-all shadow-2xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Navigation className="w-4 h-4 text-blue-600" />
                <span>1. Outdoor Satellite GPS</span>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-800">
                {gpsTrackingActive ? 'Live Watch Active' : '5 – 15m Accuracy'}
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              <strong>Best for:</strong> Campus walkways, parking lots, quadrangle grounds, and identifying which building entrance you are approaching.
            </p>
            <p className="text-xs text-rose-600 mt-1 font-medium">
              <strong>Limitations:</strong> Severely degraded inside buildings due to concrete attenuation; cannot determine floor number.
            </p>

            {liveGpsCoords && (
              <div className="mt-2.5 p-2.5 rounded-xl bg-blue-50/70 border border-blue-200/70 text-[11px] font-mono text-blue-900 grid grid-cols-2 gap-1.5">
                <div>Lat: {liveGpsCoords.lat.toFixed(6)}</div>
                <div>Lng: {liveGpsCoords.lng.toFixed(6)}</div>
                <div>Accuracy: ±{Math.round(liveGpsCoords.accuracy)}m</div>
                <div>
                  Speed:{' '}
                  {liveGpsCoords.speed !== null
                    ? `${liveGpsCoords.speed.toFixed(1)} m/s`
                    : '—'}
                </div>
              </div>
            )}

            {gpsError && (
              <div className="mt-2.5 p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{gpsError}</span>
              </div>
            )}

            <div className="mt-3 flex flex-wrap items-center gap-2">
              {gpsTrackingActive ? (
                <button
                  onClick={stopLiveGPSTracking}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs cursor-pointer shadow-2xs"
                >
                  Stop Live GPS Tracking
                </button>
              ) : (
                <button
                  onClick={startLiveGPSTracking}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs cursor-pointer shadow-2xs"
                >
                  Start Live GPS Tracking
                </button>
              )}
              <button
                onClick={async () => {
                  await requestRealGPS();
                }}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
              >
                Single GPS Fix
              </button>
            </div>
          </div>

          {/* 2. Bluetooth Low Energy (BLE) Beacons */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-purple-300 transition-all shadow-2xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Radio className="w-4 h-4 text-purple-600" />
                <span>2. Bluetooth Low Energy (BLE) Beacons</span>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                2 – 4m Accuracy
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              <strong>Hardware Infrastructure:</strong> Battery-powered iBeacon / Eddystone transmitters installed every 15–20 metres along corridors and stairwells.
            </p>
            <p className="text-xs text-slate-600 mt-1">
              <strong>Deployment:</strong> CampusNav maps RSSI signal strengths to floor nodes. Currently {beacons.length} active beacons configured in Block A, Block B, and Admin.
            </p>
            <div className="mt-3">
              <button
                onClick={() => {
                  simulateBLEScan();
                  onClose();
                }}
                className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs cursor-pointer shadow-2xs"
              >
                Scan Nearest BLE Beacon (Simulate)
              </button>
            </div>
          </div>

          {/* 3. QR-Code Checkpoints */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-300 transition-all shadow-2xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <QrCode className="w-4 h-4 text-emerald-600" />
                <span>3. High-Precision QR Checkpoints</span>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                &lt; 0.5m Exact
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              <strong>Zero Hardware Cost:</strong> High-contrast printed QR plaques mounted beside room doors, elevator lobbies, and corridor intersections.
            </p>
            <p className="text-xs text-slate-600 mt-1">
              <strong>Advantage:</strong> Instant, 100% ground-truth floor and room verification with zero battery replacement or radio interference.
            </p>
          </div>

          {/* 4. Wi-Fi Fine Timing Measurement (RTT / 802.11mc) */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-2xs">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 font-bold text-slate-900 text-sm">
                <Wifi className="w-4 h-4 text-slate-700" />
                <span>4. Campus Wi-Fi RTT / Fingerprinting</span>
              </div>
              <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-800">
                3 – 8m Accuracy
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-2 leading-relaxed">
              Utilizes campus enterprise access points (Cisco/Aruba) to calculate round-trip time. Ready for integration via university backend RADIUS / location API.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
