import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Plus,
  Minus,
  Locate,
  Layers,
  Compass,
  ArrowUp,
  Building2,
  ChevronsUpDown,
  DoorOpen,
  MapPin,
  Flag,
  RotateCcw,
} from 'lucide-react';
import { StairsIcon } from './icons/StairsIcon';
import { useCampus } from '../context/CampusContext';
import { Building, Floor, CampusLocation, NavigationNode } from '../types/campus';

export const CampusMap: React.FC = () => {
  const {
    buildings,
    floors,
    locations,
    nodes,
    connections,
    activeBuildingId,
    activeFloorId,
    setActiveBuildingId,
    setActiveFloorId,
    userPosition,
    setUserPositionManual,
    selectedDestination,
    setSelectedDestination,
    activeRoute,
    currentStepIndex,
    isNavigating,
    wrongDirectionStatus,
  } = useCampus();

  // Viewport pan & zoom transform
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [showFloorMarkers, setShowFloorMarkers] = useState(true);
  const dragStartRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const didDragRef = useRef(false);
  const svgRef = useRef<SVGSVGElement>(null);

  // Active building & floor objects
  const currentBuilding = useMemo(
    () => buildings.find(b => b.id === activeBuildingId) || null,
    [buildings, activeBuildingId]
  );

  const currentFloor = useMemo(
    () => floors.find(f => f.id === activeFloorId) || null,
    [floors, activeFloorId]
  );

  // Available floors for the active building
  const buildingFloors = useMemo(() => {
    if (!currentBuilding) return [];
    return floors
      .filter(f => f.buildingId === currentBuilding.id)
      .sort((a, b) => b.floorNumber - a.floorNumber); // Top floor down to ground
  }, [floors, currentBuilding]);

  // Destination floor for indicator
  const destinationFloor = useMemo(() => {
    if (!selectedDestination) return null;
    return floors.find(f => f.id === selectedDestination.floorId) || null;
  }, [selectedDestination, floors]);

  // Center on user position when location updates
  const handleCenterUser = () => {
    if (userPosition.buildingId !== 'outdoor' && userPosition.buildingId !== activeBuildingId) {
      setActiveBuildingId(userPosition.buildingId);
      setActiveFloorId(userPosition.floorId);
    } else if (userPosition.buildingId === 'outdoor' && activeBuildingId !== null) {
      setActiveBuildingId(null);
      setActiveFloorId('outdoor');
    }
    setZoom(1.1);
    setPan({ x: 0, y: 0 });
  };

  // Zoom handlers
  const handleZoomIn = () => setZoom(z => Math.min(2.5, z + 0.25));
  const handleZoomOut = () => setZoom(z => Math.max(0.6, z - 0.25));
  const handleResetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Pan interaction
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    didDragRef.current = false;
    dragStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.x;
    const dy = e.clientY - dragStartRef.current.y;
    if (Math.hypot(dx - pan.x, dy - pan.y) > 4) {
      didDragRef.current = true;
    }
    setPan({ x: dx, y: dy });
  };

  const handleMouseUp = () => setIsDragging(false);

  // Touch pan support
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      didDragRef.current = false;
      dragStartRef.current = {
        x: e.touches[0].clientX - pan.x,
        y: e.touches[0].clientY - pan.y,
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    didDragRef.current = true;
    setPan({
      x: e.touches[0].clientX - dragStartRef.current.x,
      y: e.touches[0].clientY - dragStartRef.current.y,
    });
  };

  // Map Click (accurate SVG coordinate projection for placing current position)
  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (didDragRef.current) return;
    if (svgRef.current) {
      const pt = svgRef.current.createSVGPoint();
      pt.x = e.clientX;
      pt.y = e.clientY;
      const ctm = svgRef.current.getScreenCTM();
      if (!ctm) return;
      const transformed = pt.matrixTransform(ctm.inverse());
      const clickX = (transformed.x - pan.x) / zoom;
      const clickY = (transformed.y - pan.y) / zoom;

      if (!isNavigating) {
        setUserPositionManual({
          x: Math.max(20, Math.min(980, Math.round(clickX))),
          y: Math.max(20, Math.min(630, Math.round(clickY))),
          buildingId: activeBuildingId || 'outdoor',
          floorId: activeFloorId || 'outdoor',
          method: 'manual',
          accuracyMeters: 2,
          confirmedLocationName: currentFloor
            ? `${currentBuilding?.name.split(' (')[0]} – ${currentFloor.floorName}`
            : 'Canara Engineering College Grounds',
        });
      }
    }
  };

  // Filtered route points for the active view
  const activeRoutePolyline = useMemo(() => {
    if (!activeRoute) return null;
    const isOutdoorView = activeBuildingId === null || activeFloorId === 'outdoor';

    const points = activeRoute.nodePath
      .filter(n => {
        if (isOutdoorView) {
          return n.floorId === 'outdoor';
        }
        return n.floorId === activeFloorId && n.buildingId === activeBuildingId;
      })
      .map(n => `${n.x},${n.y}`)
      .join(' ');

    return points || null;
  }, [activeRoute, activeBuildingId, activeFloorId]);

  // Locations on current floor
  const visibleLocations = useMemo(() => {
    if (activeBuildingId === null || activeFloorId === 'outdoor') {
      return locations.filter(l => l.buildingId === 'outdoor');
    }
    return locations.filter(l => l.floorId === activeFloorId && l.buildingId === activeBuildingId);
  }, [locations, activeBuildingId, activeFloorId]);

  // Staircases and elevators on current floor
  const visibleVerticalNodes = useMemo(() => {
    if (activeBuildingId === null || activeFloorId === 'outdoor') return [];
    return nodes.filter(
      n =>
        n.buildingId === activeBuildingId &&
        n.floorId === activeFloorId &&
        (n.nodeType === 'staircase' || n.nodeType === 'elevator')
    );
  }, [nodes, activeBuildingId, activeFloorId]);

  // Is user currently on the active view?
  const isUserVisibleOnMap = useMemo(() => {
    if (activeBuildingId === null || activeFloorId === 'outdoor') {
      return userPosition.floorId === 'outdoor';
    }
    return userPosition.buildingId === activeBuildingId && userPosition.floorId === activeFloorId;
  }, [userPosition, activeBuildingId, activeFloorId]);

  // Should the destination pin render on this exact floor?
  const isDestinationOnCurrentView = useMemo(() => {
    if (!selectedDestination) return false;
    if (activeBuildingId === null || activeFloorId === 'outdoor') {
      return selectedDestination.floorId === 'outdoor';
    }
    return (
      selectedDestination.buildingId === activeBuildingId &&
      selectedDestination.floorId === activeFloorId
    );
  }, [selectedDestination, activeBuildingId, activeFloorId]);

  return (
    <div className="relative w-full h-[460px] sm:h-[540px] lg:h-[580px] bg-[#f8fafc] rounded-3xl overflow-hidden border border-slate-200/90 shadow-inner select-none">
      {/* Map Header Status Overlay */}
      <div className="absolute top-3 left-3 z-10 flex flex-wrap items-center gap-2 max-w-[85%]">
        {/* Current View Indicator Pill */}
        <div className="bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-200/80 shadow-xs flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse" />
          <div className="text-xs">
            <span className="font-bold text-slate-800">
              {currentBuilding ? currentBuilding.name : 'Campus Grounds & Master Plan'}
            </span>
            {currentFloor && (
              <span className="text-slate-500 font-medium ml-1">
                • {currentFloor.floorName.includes(`(${currentFloor.code})`)
                  ? currentFloor.floorName
                  : `${currentFloor.floorName} (${currentFloor.code})`}
              </span>
            )}
          </div>
        </div>

        {/* Back to Campus Master Plan button if indoors */}
        {currentBuilding && (
          <>
            <button
              onClick={() => {
                setActiveBuildingId(null);
                setActiveFloorId('outdoor');
              }}
              className="bg-white/95 backdrop-blur-md hover:bg-slate-100 text-slate-700 px-2.5 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-blue-600" />
              <span>Campus Overview</span>
            </button>

            <button
              onClick={() => setShowFloorMarkers(prev => !prev)}
              className={`px-2.5 py-1.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer ${
                showFloorMarkers
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-white/95 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
              title="Toggle room pins on floor layout"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{showFloorMarkers ? 'Room Pins On' : 'Room Pins Off'}</span>
            </button>
          </>
        )}
      </div>

      {/* Tap hint pill on bottom-left when idle */}
      {!isNavigating && (
        <div className="hidden sm:flex absolute bottom-3 left-3 z-10 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl border border-slate-200/80 shadow-xs text-[11px] font-medium text-slate-600 items-center gap-1.5 pointer-events-none">
          <MapPin className="w-3.5 h-3.5 text-blue-600" />
          <span>
            {currentFloor?.floorMapImage
              ? 'Tap any blue room marker to select destination, or tap anywhere on the plan to set your position'
              : 'Click any block to view its uploaded floor plans, or tap the map to set your position'}
          </span>
        </div>
      )}

      {/* Floating Floor Selector Widget (Vertical Pill on Right) */}
      {currentBuilding && buildingFloors.length > 0 && (
        <div className="absolute right-3 top-16 z-10 flex flex-col bg-white/95 backdrop-blur-md rounded-2xl p-1.5 border border-slate-200 shadow-lg">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center pb-1 border-b border-slate-100 mb-1">
            Floor
          </div>
          <div className="flex flex-col gap-1">
            {buildingFloors.map(f => {
              const isActive = f.id === activeFloorId;
              const isUserFloor = userPosition.floorId === f.id;
              const isDestFloor = destinationFloor?.id === f.id;

              return (
                <button
                  key={f.id}
                  onClick={() => setActiveFloorId(f.id)}
                  className={`relative w-10 h-9 rounded-xl flex items-center justify-center font-bold text-xs transition-all cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                      : 'hover:bg-slate-100 text-slate-700'
                  }`}
                  title={`${f.floorName} (${f.code})`}
                >
                  <span>{f.code}</span>
                  {/* Indicators */}
                  {isUserFloor && (
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-white ring-1 ring-emerald-600" title="You are on this floor" />
                  )}
                  {isDestFloor && !isUserFloor && (
                    <span className="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white ring-1 ring-rose-600" title="Destination floor" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating Map Controls (Zoom, Center) */}
      <div className="absolute right-3 bottom-4 z-10 flex flex-col gap-2">
        <div className="bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200 shadow-md p-1 flex flex-col gap-1">
          <button
            onClick={handleZoomIn}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Zoom In"
          >
            <Plus className="w-4 h-4" />
          </button>
          <div className="h-px bg-slate-200 mx-1" />
          <button
            onClick={handleZoomOut}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Zoom Out"
          >
            <Minus className="w-4 h-4" />
          </button>
          <div className="h-px bg-slate-200 mx-1" />
          <button
            onClick={handleResetView}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            title="Reset View"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          onClick={handleCenterUser}
          className="w-10 h-10 bg-white/95 backdrop-blur-md rounded-2xl border border-slate-200 shadow-md flex items-center justify-center text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
          title="Center on My Location"
        >
          <Locate className="w-5 h-5" />
        </button>
      </div>

      {/* SVG Canvas Map Surface */}
      <svg
        ref={svgRef}
        viewBox="0 0 1000 650"
        className="w-full h-full cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleMouseUp}
        onClick={handleSvgClick}
      >
        <defs>
          {/* Subtle grid pattern */}
          <pattern id="campusGrid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" strokeWidth="0.8" opacity="0.6" />
          </pattern>

          {/* Grass lawn texture */}
          <pattern id="lawnDots" width="16" height="16" patternUnits="userSpaceOnUse">
            <circle cx="8" cy="8" r="1.5" fill="#86efac" opacity="0.4" />
          </pattern>

          {/* Drop shadow filter for buildings */}
          <filter id="buildingShadow" x="-10%" y="-10%" width="130%" height="130%">
            <feDropShadow dx="2" dy="5" stdDeviation="6" floodOpacity="0.12" />
          </filter>

          {/* Glow filter for active route */}
          <filter id="routeGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>

          {/* Marker arrow for polyline */}
          <marker id="navArrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 10 5 L 0 9 z" fill="#1d4ed8" />
          </marker>
        </defs>

        {/* Dynamic Zoom & Pan Group */}
        <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
          {/* ============================================================== */}
          {/* 1. OUTDOOR CAMPUS MASTER PLAN VIEW                              */}
          {/* ============================================================== */}
          {activeBuildingId === null || activeFloorId === 'outdoor' ? (
            <g id="outdoorView">
              {/* Campus Base Terrain */}
              <rect x="0" y="0" width="1000" height="650" fill="#f8fafc" />
              <rect x="0" y="0" width="1000" height="650" fill="url(#campusGrid)" />

              {/* Campus Header Banner */}
              <text x="500" y="65" textAnchor="middle" fill="#0f172a" fontSize="18" fontWeight="800" letterSpacing="1.5">
                CANARA ENGINEERING COLLEGE
              </text>
              <text x="500" y="88" textAnchor="middle" fill="#64748b" fontSize="11.5" fontWeight="600">
                Sudhindra Nagar, Benjanapadavu • Interactive Campus Master Plan (Tap a block to view Floor Layouts)
              </text>

              {/* Campus Walkways (rendered beneath courtyard quad & gate plaza) */}
              <path d="M 500 560 L 500 310" stroke="#cbd5e1" strokeWidth="24" strokeLinecap="round" />
              <path d="M 210 420 L 795 420" stroke="#cbd5e1" strokeWidth="20" strokeLinecap="round" />
              <path d="M 210 420 L 210 310" stroke="#cbd5e1" strokeWidth="18" strokeLinecap="round" />
              <path d="M 795 420 L 795 310" stroke="#cbd5e1" strokeWidth="18" strokeLinecap="round" />
              <path d="M 500 560 L 500 420" stroke="#ffffff" strokeWidth="2" strokeDasharray="8 6" />

              {/* Central Campus Lawn & Quad */}
              <rect x="330" y="345" width="340" height="55" rx="14" fill="#dcfce7" stroke="#bbf7d0" strokeWidth="2" />
              <rect x="330" y="345" width="340" height="55" rx="14" fill="url(#lawnDots)" />
              <text x="500" y="378" textAnchor="middle" fill="#15803d" fontSize="11" fontWeight="700" letterSpacing="1">
                CAMPUS COURTYARD & WALKWAY
              </text>

              {/* Entrance Gate Plaza */}
              <circle cx="500" cy="560" r="32" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="3" />
              <circle cx="500" cy="560" r="14" fill="#3b82f6" opacity="0.15" />
              <text x="500" y="610" textAnchor="middle" fill="#334155" fontSize="11" fontWeight="800">
                MAIN CAMPUS ENTRANCE GATE
              </text>

              {/* Outdoor Walking Connections */}
              {connections
                .filter(c => c.connectionType === 'outdoor_path')
                .map(c => {
                  const s = nodes.find(n => n.id === c.startNodeId);
                  const e = nodes.find(n => n.id === c.endNodeId);
                  if (!s || !e) return null;
                  return (
                    <line
                      key={c.id}
                      x1={s.x}
                      y1={s.y}
                      x2={e.x}
                      y2={e.y}
                      stroke="#94a3b8"
                      strokeWidth="2.5"
                      strokeDasharray="4 4"
                      opacity="0.7"
                    />
                  );
                })}

              {/* Campus Buildings (Interactive Footprints) */}
              {buildings.map(b => {
                const isSelected = selectedDestination?.buildingId === b.id;
                const bFloors = floors.filter(f => f.buildingId === b.id);
                const floorCodes = bFloors.map(f => f.code).join(' • ');
                const previewFloor = bFloors.find(f => f.floorMapImage);
                return (
                  <g
                    key={b.id}
                    className="cursor-pointer group"
                    onClick={e => {
                      e.stopPropagation();
                      setActiveBuildingId(b.id);
                    }}
                  >
                    {/* Shadow & Building Block Outline */}
                    <rect
                      x={b.canvasBounds.x}
                      y={b.canvasBounds.y}
                      width={b.canvasBounds.width}
                      height={b.canvasBounds.height}
                      rx="16"
                      fill="#ffffff"
                      stroke={isSelected ? '#2563eb' : b.color}
                      strokeWidth={isSelected ? 4 : 2.5}
                      filter="url(#buildingShadow)"
                      className="transition-all duration-200 group-hover:brightness-95"
                    />

                    {/* Subtle Blueprint Thumbnail Watermark inside Block Card */}
                    {previewFloor?.floorMapImage && (
                      <image
                        href={previewFloor.floorMapImage}
                        x={b.canvasBounds.x + 12}
                        y={b.canvasBounds.y + 34}
                        width={b.canvasBounds.width - 24}
                        height={b.canvasBounds.height - 68}
                        preserveAspectRatio="xMidYMid slice"
                        opacity="0.22"
                      />
                    )}

                    {/* Roof Accent Band */}
                    <rect
                      x={b.canvasBounds.x}
                      y={b.canvasBounds.y}
                      width={b.canvasBounds.width}
                      height="30"
                      rx="14"
                      fill={b.color}
                      opacity="0.92"
                    />
                    <text
                      x={b.canvasBounds.x + b.canvasBounds.width / 2}
                      y={b.canvasBounds.y + 20}
                      textAnchor="middle"
                      fill="#ffffff"
                      fontSize="11.5"
                      fontWeight="800"
                      letterSpacing="0.8"
                    >
                      {b.code}
                    </text>

                    {/* Building Name */}
                    <text
                      x={b.canvasBounds.x + b.canvasBounds.width / 2}
                      y={b.canvasBounds.y + 62}
                      textAnchor="middle"
                      fill="#0f172a"
                      fontSize="14"
                      fontWeight="800"
                    >
                      {b.name.split(' (')[0]}
                    </text>
                    <text
                      x={b.canvasBounds.x + b.canvasBounds.width / 2}
                      y={b.canvasBounds.y + 82}
                      textAnchor="middle"
                      fill="#475569"
                      fontSize="10"
                      fontWeight="700"
                    >
                      Floors: {floorCodes}
                    </text>

                    {/* Enter Floor Plan Tag */}
                    <rect
                      x={b.canvasBounds.x + b.canvasBounds.width / 2 - 64}
                      y={b.canvasBounds.y + 115}
                      width="128"
                      height="24"
                      rx="12"
                      fill="#eff6ff"
                      stroke="#bfdbfe"
                      strokeWidth="1"
                    />
                    <text
                      x={b.canvasBounds.x + b.canvasBounds.width / 2}
                      y={b.canvasBounds.y + 131}
                      textAnchor="middle"
                      fill="#1d4ed8"
                      fontSize="10"
                      fontWeight="700"
                    >
                      Open Floor Plans →
                    </text>

                    {/* Entrance Marker */}
                    <circle
                      cx={b.canvasBounds.x + b.canvasBounds.width / 2}
                      cy={b.canvasBounds.y + b.canvasBounds.height}
                      r="6"
                      fill="#2563eb"
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                  </g>
                );
              })}
            </g>
          ) : (
            /* ============================================================== */
            /* 2. INDOOR BUILDING FLOOR PLAN VIEW (UPLOADED BLUEPRINTS)       */
            /* ============================================================== */
            <g id="indoorFloorPlan">
              <rect x="0" y="0" width="1000" height="650" fill="#f1f5f9" />

              {currentFloor?.floorMapImage ? (
                <g id="uploadedBlueprintLayer">
                  {/* Crisp White Drawing Sheet Backing */}
                  <rect
                    x="10"
                    y="10"
                    width="980"
                    height="630"
                    rx="14"
                    fill="#ffffff"
                    stroke="#cbd5e1"
                    strokeWidth="2"
                    filter="url(#buildingShadow)"
                  />

                  {/* Uploaded Architectural Floor Layout Image */}
                  <image
                    href={currentFloor.floorMapImage}
                    x="10"
                    y="10"
                    width="980"
                    height="630"
                    preserveAspectRatio="xMidYMid meet"
                  />

                  {/* Subtle Corridor Graph Network Overlay during navigation */}
                  {isNavigating &&
                    connections
                      .filter(c => {
                        const s = nodes.find(n => n.id === c.startNodeId);
                        const e = nodes.find(n => n.id === c.endNodeId);
                        return (
                          s &&
                          e &&
                          s.floorId === activeFloorId &&
                          e.floorId === activeFloorId
                        );
                      })
                      .map(c => {
                        const s = nodes.find(n => n.id === c.startNodeId)!;
                        const e = nodes.find(n => n.id === c.endNodeId)!;
                        return (
                          <line
                            key={c.id}
                            x1={s.x}
                            y1={s.y}
                            x2={e.x}
                            y2={e.y}
                            stroke="#94a3b8"
                            strokeWidth="1.5"
                            strokeDasharray="3 3"
                            opacity="0.45"
                          />
                        );
                      })}

                  {/* Vertical Transition Badges (Stairs & Lift) */}
                  {showFloorMarkers &&
                    visibleVerticalNodes.map(vn => {
                      const isLift = vn.nodeType === 'elevator';
                      return (
                        <g
                          key={vn.id}
                          transform={`translate(${vn.x}, ${vn.y})`}
                          className="pointer-events-none"
                        >
                          <rect
                            x="-26"
                            y="-11"
                            width="52"
                            height="22"
                            rx="11"
                            fill={isLift ? '#dbeafe' : '#fef3c7'}
                            stroke={isLift ? '#2563eb' : '#d97706'}
                            strokeWidth="1.5"
                          />
                          <text
                            x="0"
                            y="3.5"
                            textAnchor="middle"
                            fill={isLift ? '#1e40af' : '#92400e'}
                            fontSize="8.5"
                            fontWeight="800"
                          >
                            {isLift ? '↕ LIFT' : '🪜 STAIRS'}
                          </text>
                        </g>
                      );
                    })}

                  {/* Interactive Clickable Room Pins Overlaid on Blueprint */}
                  {showFloorMarkers &&
                    visibleLocations.map(loc => {
                      const isSelected = selectedDestination?.id === loc.id;
                      const shortName =
                        loc.name.length > 20
                          ? `${loc.name.slice(0, 19)}…`
                          : loc.name;
                      return (
                        <g
                          key={loc.id}
                          transform={`translate(${loc.coordinates.x}, ${loc.coordinates.y})`}
                          className="cursor-pointer group"
                          onClick={e => {
                            e.stopPropagation();
                            setSelectedDestination(loc);
                          }}
                        >
                          {/* Subtle pin ring */}
                          <circle
                            cx="0"
                            cy="0"
                            r={isSelected ? 10 : 7}
                            fill={isSelected ? '#dc2626' : '#2563eb'}
                            stroke="#ffffff"
                            strokeWidth="2"
                          />
                          {/* Floating readable pill tag */}
                          <g transform="translate(0, -16)">
                            <rect
                              x="-54"
                              y="-11"
                              width="108"
                              height="18"
                              rx="9"
                              fill={isSelected ? '#dc2626' : '#0f172a'}
                              opacity="0.86"
                              className="group-hover:opacity-100 transition-opacity"
                            />
                            <text
                              x="0"
                              y="1"
                              textAnchor="middle"
                              fill="#ffffff"
                              fontSize="8"
                              fontWeight="700"
                            >
                              {shortName}
                            </text>
                          </g>
                        </g>
                      );
                    })}
                </g>
              ) : (
                /* Fallback schematic view for floors without an uploaded blueprint image */
                <g transform="translate(150, 60)">
                  <rect
                    x="0"
                    y="0"
                    width="700"
                    height="480"
                    rx="18"
                    fill="#ffffff"
                    stroke="#334155"
                    strokeWidth="6"
                    filter="url(#buildingShadow)"
                  />
                  <rect x="180" y="160" width="480" height="120" fill="#f1f5f9" stroke="#cbd5e1" strokeWidth="2" />
                  <text x="420" y="225" textAnchor="middle" fill="#94a3b8" fontSize="12" fontWeight="700" letterSpacing="2">
                    MAIN CORRIDOR ({currentFloor?.floorName.toUpperCase()})
                  </text>
                  <g transform="translate(30, 40)">
                    <rect x="0" y="0" width="120" height="160" rx="10" fill="#fef3c7" stroke="#d97706" strokeWidth="2.5" />
                    <StairsIcon className="w-5 h-5 text-amber-700 mx-auto" />
                    <text x="60" y="45" textAnchor="middle" fill="#92400e" fontSize="11" fontWeight="800">
                      STAIRCASE
                    </text>
                    <text x="60" y="65" textAnchor="middle" fill="#b45309" fontSize="9">
                      Access to Upper Floors
                    </text>
                  </g>
                  <g transform="translate(300, 360)">
                    <rect x="0" y="0" width="240" height="114" rx="8" fill="#e2e8f0" stroke="#64748b" strokeWidth="2" strokeDasharray="6 4" />
                    <text x="120" y="55" textAnchor="middle" fill="#334155" fontSize="11" fontWeight="700">
                      ENTRANCE FOYER & RECEPTION
                    </text>
                    <text x="120" y="75" textAnchor="middle" fill="#64748b" fontSize="9">
                      Select SF above to view uploaded Second Floor blueprint
                    </text>
                  </g>
                </g>
              )}
            </g>
          )}

          {/* ============================================================== */}
          {/* 3. ACTIVE ROUTE POLYLINE & CHEVRONS                            */}
          {/* ============================================================== */}
          {activeRoutePolyline && (
            <g id="activeRouteOverlay">
              {/* Soft background glow */}
              <polyline
                points={activeRoutePolyline}
                fill="none"
                stroke="#60a5fa"
                strokeWidth="12"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.45"
                filter="url(#routeGlow)"
              />
              {/* Solid core line */}
              <polyline
                points={activeRoutePolyline}
                fill="none"
                stroke="#2563eb"
                strokeWidth="6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Animated marching directional chevrons */}
              <polyline
                points={activeRoutePolyline}
                fill="none"
                stroke="#ffffff"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray="6 12"
                className="animate-route-flow"
              />
            </g>
          )}

          {/* ============================================================== */}
          {/* 4. DESTINATION PIN / TARGET FLAG                               */}
          {/* ============================================================== */}
          {selectedDestination && isDestinationOnCurrentView && (
            <g
              transform={`translate(${selectedDestination.coordinates.x}, ${selectedDestination.coordinates.y})`}
              className="transition-transform pointer-events-none"
            >
              {/* Destination Beacon Ring */}
              <circle cx="0" cy="0" r="18" fill="#ef4444" opacity="0.25" className="animate-ping" />
              <circle cx="0" cy="0" r="8" fill="#ef4444" stroke="#ffffff" strokeWidth="2" />
              {/* Pin glyph */}
              <g transform="translate(-12, -30)">
                <path
                  d="M 12 0 C 5.37 0 0 5.37 0 12 C 0 21 12 32 12 32 C 12 32 24 21 24 12 C 24 5.37 18.63 0 12 0 Z"
                  fill="#dc2626"
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
                <circle cx="12" cy="11" r="4.5" fill="#ffffff" />
              </g>
              <rect x="-56" y="12" width="112" height="20" rx="6" fill="#0f172a" opacity="0.92" />
              <text x="0" y="25.5" textAnchor="middle" fill="#ffffff" fontSize="9.5" fontWeight="700">
                {selectedDestination.name.substring(0, 18)}
              </text>
            </g>
          )}

          {/* ============================================================== */}
          {/* 5. USER LIVE BLUE LOCATION DOT (With Heading & Radar Pulse)    */}
          {/* ============================================================== */}
          {isUserVisibleOnMap && (
            <g
              transform={`translate(${userPosition.x}, ${userPosition.y})`}
              className="cursor-pointer"
            >
              {/* Accuracy radius ring */}
              <circle
                cx="0"
                cy="0"
                r={Math.max(16, userPosition.accuracyMeters * 2)}
                fill="#3b82f6"
                opacity="0.12"
                stroke="#60a5fa"
                strokeWidth="1"
              />

              {/* Pulsing radar wave ring */}
              <circle cx="0" cy="0" r="14" fill="#2563eb" opacity="0.4" className="animate-ping" />

              {/* Heading directional cone */}
              <g transform={`rotate(${userPosition.heading})`}>
                <polygon points="0,-18 -7,-4 7,-4" fill="#2563eb" opacity="0.9" />
              </g>

              {/* Blue Core Dot with Crisp White Border */}
              <circle cx="0" cy="0" r="8.5" fill="#2563eb" stroke="#ffffff" strokeWidth="2.5" />
              <circle cx="0" cy="0" r="3" fill="#ffffff" />

              {/* Wrong Direction Warning Ring if active */}
              {wrongDirectionStatus?.isWrongDirection && (
                <circle
                  cx="0"
                  cy="0"
                  r="24"
                  fill="none"
                  stroke="#dc2626"
                  strokeWidth="3"
                  strokeDasharray="4 4"
                  className="animate-spin"
                />
              )}
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};
