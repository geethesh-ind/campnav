import React, { useState, useEffect } from 'react';
import {
  QrCode,
  X,
  CheckCircle2,
  Printer,
  Sparkles,
  MapPin,
  Building2,
  Scan,
  Compass,
} from 'lucide-react';
import QRCode from 'qrcode';
import { useCampus } from '../context/CampusContext';
import { QRCheckpoint } from '../types/campus';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QRScannerModal: React.FC<QRScannerModalProps> = ({ isOpen, onClose }) => {
  const { qrCheckpoints, confirmLocationByQR, buildings, floors } = useCampus();
  const [activeTab, setActiveTab] = useState<'scan' | 'print'>('scan');
  const [selectedCheckpointForPrint, setSelectedCheckpointForPrint] = useState<QRCheckpoint | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [scanFeedback, setScanFeedback] = useState<string | null>(null);

  useEffect(() => {
    if (qrCheckpoints.length > 0 && !selectedCheckpointForPrint) {
      setSelectedCheckpointForPrint(qrCheckpoints[0]);
    }
  }, [qrCheckpoints, selectedCheckpointForPrint]);

  useEffect(() => {
    if (selectedCheckpointForPrint) {
      QRCode.toDataURL(selectedCheckpointForPrint.code, {
        width: 240,
        margin: 2,
        color: {
          dark: '#1e293b',
          light: '#ffffff',
        },
      })
        .then(url => setQrDataUrl(url))
        .catch(() => {});
    }
  }, [selectedCheckpointForPrint]);

  if (!isOpen) return null;

  const handleSimulateScan = (checkpoint: QRCheckpoint) => {
    const res = confirmLocationByQR(checkpoint.code);
    if (res.success) {
      setScanFeedback(res.message);
      setTimeout(() => {
        setScanFeedback(null);
        onClose();
      }, 1400);
    }
  };

  const getCheckpointMeta = (cp: QRCheckpoint) => {
    const b = buildings.find(item => item.id === cp.buildingId);
    const f = floors.find(item => item.id === cp.floorId);
    return {
      buildingName: b ? b.name : 'Campus Grounds',
      floorName: f ? f.floorName : 'Outdoor Grounds',
    };
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                Indoor QR Location Verification
              </h3>
              <p className="text-xs text-slate-500">
                Exact room & floor positioning with zero GPS drift
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="px-5 pt-3 flex items-center gap-2 border-b border-slate-100 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('scan')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'scan'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Scan className="w-4 h-4" />
            <span>Scan & Checkpoint List</span>
          </button>
          <button
            onClick={() => setActiveTab('print')}
            className={`pb-2.5 border-b-2 transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'print'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Printer className="w-4 h-4" />
            <span>Printable Campus QR Signage</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1">
          {activeTab === 'scan' ? (
            <div>
              {/* Scan Success Toast */}
              {scanFeedback && (
                <div className="mb-4 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-2.5 animate-in fade-in">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span className="text-sm font-bold">{scanFeedback}</span>
                </div>
              )}

              {/* Explainer Banner */}
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 mb-4 text-xs text-slate-600">
                <span className="font-bold text-slate-800 block mb-1">
                  How Indoor Checkpoints Work:
                </span>
                Because satellite GPS cannot reliably detect whether you are on the Ground Floor or the 2nd Floor inside concrete academic buildings, CampusNav allows students to tap or scan QR checkpoint plaques mounted at stairwells, foyers, and room doors.
              </div>

              {/* Test Checkpoints List */}
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Simulate Scanning a Checkpoint
              </h4>
              <div className="space-y-2">
                {qrCheckpoints.map(cp => {
                  const meta = getCheckpointMeta(cp);
                  return (
                    <div
                      key={cp.id}
                      onClick={() => handleSimulateScan(cp)}
                      className="p-3 rounded-2xl bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-300 transition-all cursor-pointer flex items-center justify-between group shadow-2xs"
                    >
                      <div className="flex items-start gap-2.5 min-w-0">
                        <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-600 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center shrink-0 transition-colors">
                          <MapPin className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <h5 className="text-xs sm:text-sm font-bold text-slate-800 group-hover:text-blue-900 truncate">
                            {cp.label}
                          </h5>
                          <p className="text-[11px] text-slate-500 truncate mt-0.5">
                            {meta.buildingName} • {meta.floorName}
                          </p>
                          <span className="inline-block px-1.5 py-0.2 rounded bg-slate-100 font-mono text-[9.5px] text-slate-500 mt-1">
                            {cp.code}
                          </span>
                        </div>
                      </div>

                      <button className="px-2.5 py-1 rounded-lg bg-blue-600 text-white font-semibold text-xs shrink-0 group-hover:bg-blue-700 transition-colors shadow-2xs">
                        Scan Here
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Printable Signage Tab */
            <div>
              <div className="mb-3 text-xs text-slate-600">
                Select a checkpoint to preview and print its official high-contrast indoor navigation plaque for campus hallways:
              </div>

              {/* Checkpoint selector */}
              <div className="mb-4">
                <select
                  value={selectedCheckpointForPrint?.id || ''}
                  onChange={e => {
                    const found = qrCheckpoints.find(c => c.id === e.target.value);
                    if (found) setSelectedCheckpointForPrint(found);
                  }}
                  className="w-full text-xs font-semibold p-2.5 rounded-xl border border-slate-200 bg-white text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                >
                  {qrCheckpoints.map(cp => (
                    <option key={cp.id} value={cp.id}>
                      {cp.label} ({cp.code})
                    </option>
                  ))}
                </select>
              </div>

              {/* Printable Plaque Card */}
              {selectedCheckpointForPrint && (
                <div className="p-6 rounded-3xl bg-white border-2 border-slate-800 shadow-xl text-center max-w-sm mx-auto">
                  <div className="flex items-center justify-center gap-1.5 mb-2">
                    <Compass className="w-5 h-5 text-blue-600" />
                    <span className="font-extrabold text-sm tracking-tight text-slate-900">
                      Campus<span className="text-blue-600">Nav</span> Checkpoint
                    </span>
                  </div>

                  <h3 className="font-extrabold text-base text-slate-900 leading-tight">
                    {selectedCheckpointForPrint.label}
                  </h3>

                  <div className="my-4 flex items-center justify-center">
                    {qrDataUrl ? (
                      <img
                        src={qrDataUrl}
                        alt={`QR Code for ${selectedCheckpointForPrint.label}`}
                        className="w-48 h-48 rounded-xl border border-slate-200 shadow-xs"
                      />
                    ) : (
                      <div className="w-48 h-48 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400">
                        Generating QR...
                      </div>
                    )}
                  </div>

                  <div className="bg-slate-100 px-3 py-1.5 rounded-lg inline-block text-xs font-mono font-bold text-slate-800 tracking-wider mb-2">
                    {selectedCheckpointForPrint.code}
                  </div>

                  <p className="text-[11px] text-slate-500">
                    Scan with your smartphone camera or CampusNav app to confirm your exact indoor floor & location.
                  </p>
                </div>
              )}

              <div className="mt-4 text-center">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 mx-auto cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Checkpoint Plaque</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
