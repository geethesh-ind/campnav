import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Search,
  X,
  MapPin,
  Building2,
  Users,
  FlaskConical,
  GraduationCap,
  BookOpen,
  Coffee,
  Briefcase,
  Layers,
  Car,
  ShieldAlert,
  ArrowRight,
  Compass,
} from 'lucide-react';
import { useCampus } from '../context/CampusContext';
import { CampusLocation, LocationCategory } from '../types/campus';

const CATEGORY_ITEMS: { key: LocationCategory | 'all'; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: 'all', label: 'All Places', icon: Compass },
  { key: 'staff_room', label: 'Staff Rooms', icon: Users },
  { key: 'lab', label: 'Laboratories', icon: FlaskConical },
  { key: 'classroom', label: 'Classrooms', icon: GraduationCap },
  { key: 'department', label: 'Departments', icon: Building2 },
  { key: 'office', label: 'Offices', icon: Briefcase },
  { key: 'library', label: 'Library', icon: BookOpen },
  { key: 'canteen', label: 'Canteen', icon: Coffee },
  { key: 'parking', label: 'Parking', icon: Car },
  { key: 'emergency', label: 'Emergency', icon: ShieldAlert },
];

const QUICK_SEARCH_EXAMPLES = [
  { query: 'Central Library', label: 'Where is Central Library?' },
  { query: 'Computer Lab 02', label: 'Find Computer Lab 02' },
  { query: 'Class Room 05', label: 'Find Class Room 05' },
  { query: 'HOD', label: 'HOD / Department Cabins' },
  { query: 'Staff Room', label: 'Find Staff Room' },
  { query: 'Lab-01', label: 'Where is Lab-01?' },
];

export const SearchBar: React.FC = () => {
  const {
    locations,
    buildings,
    floors,
    searchQuery,
    setSearchQuery,
    setSelectedDestination,
    startNavigation,
    setActiveBuildingId,
    setActiveFloorId,
    isNavigating,
  } = useCampus();

  const [isOpen, setIsOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<LocationCategory | 'all'>('all');
  const searchInputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Filtered locations
  const filteredLocations = useMemo(() => {
    let list = locations;

    if (selectedCategory !== 'all') {
      list = list.filter(l => l.category === selectedCategory);
    }

    if (!searchQuery.trim()) {
      return list;
    }

    const q = searchQuery.toLowerCase().trim();
    return list.filter(l => {
      const matchName = l.name.toLowerCase().includes(q);
      const matchRoom = l.roomNumber.toLowerCase().includes(q);
      const matchDesc = l.description.toLowerCase().includes(q);
      const matchTags = l.tags?.some(t => t.toLowerCase().includes(q));
      const matchFaculty = l.facultyInfo?.name.toLowerCase().includes(q) ||
        l.facultyInfo?.department.toLowerCase().includes(q);

      // Building match
      const building = buildings.find(b => b.id === l.buildingId);
      const matchBuilding = building?.name.toLowerCase().includes(q) || building?.code.toLowerCase().includes(q);

      return matchName || matchRoom || matchDesc || matchTags || matchFaculty || matchBuilding;
    });
  }, [locations, selectedCategory, searchQuery, buildings]);

  const handleSelectLocation = (loc: CampusLocation, autoStart = false) => {
    setSelectedDestination(loc);
    setActiveBuildingId(loc.buildingId === 'outdoor' ? null : loc.buildingId);
    setActiveFloorId(loc.floorId);
    setIsOpen(false);

    if (autoStart) {
      startNavigation(loc);
    }
  };

  const getLocationMeta = (loc: CampusLocation) => {
    const b = buildings.find(item => item.id === loc.buildingId);
    const f = floors.find(item => item.id === loc.floorId);
    return {
      buildingName: b ? b.name : 'Campus Grounds',
      floorName: f ? f.floorName : 'Outdoor Grounds',
    };
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-xl mx-auto z-20">
      {/* Search Input Bar */}
      <div className="relative flex items-center bg-white rounded-2xl shadow-lg shadow-slate-200/80 border border-slate-200/90 transition-all focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500">
        <div className="pl-4 pr-2 text-slate-400">
          <Search className="w-5 h-5 text-blue-600" />
        </div>
        <input
          ref={searchInputRef}
          type="text"
          value={searchQuery}
          onChange={e => {
            setSearchQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search rooms, labs, staff rooms (e.g. Central Library, Lab PC-01, Class Room 05)"
          className="w-full py-3 pr-10 text-sm sm:text-base text-slate-800 placeholder:text-slate-400 bg-transparent focus:outline-hidden font-medium"
        />
        {searchQuery && (
          <button
            onClick={() => {
              setSearchQuery('');
              searchInputRef.current?.focus();
            }}
            className="p-2 text-slate-400 hover:text-slate-600 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Categories chips bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto py-2 px-1 no-scrollbar text-xs">
        {CATEGORY_ITEMS.map(cat => {
          const Icon = cat.icon;
          const isActive = selectedCategory === cat.key;
          return (
            <button
              key={cat.key}
              onClick={() => {
                setSelectedCategory(cat.key);
                setIsOpen(true);
              }}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full whitespace-nowrap font-medium transition-all cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 shadow-2xs'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Autocomplete Dropdown */}
      {isOpen && (
        <div className="absolute left-0 right-0 top-[102px] mt-1 bg-white rounded-2xl shadow-2xl border border-slate-200 max-h-[460px] overflow-y-auto p-2 z-30 divide-y divide-slate-100">
          {/* Quick Examples Suggestions if search is empty */}
          {!searchQuery.trim() && selectedCategory === 'all' && (
            <div className="p-2 mb-1">
              <span className="text-[11px] uppercase tracking-wider font-bold text-slate-400">
                Suggested Searches
              </span>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {QUICK_SEARCH_EXAMPLES.map(ex => (
                  <button
                    key={ex.query}
                    onClick={() => {
                      setSearchQuery(ex.query);
                      searchInputRef.current?.focus();
                    }}
                    className="text-xs bg-slate-50 hover:bg-blue-50 hover:text-blue-700 text-slate-600 px-2.5 py-1 rounded-lg border border-slate-200/80 transition-colors cursor-pointer"
                  >
                    "{ex.label}"
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Results list */}
          <div className="py-1">
            <div className="px-2 py-1 flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-400">
              <span>{selectedCategory === 'all' ? 'Destinations' : `${selectedCategory} Results`}</span>
              <span>{filteredLocations.length} found</span>
            </div>

            {filteredLocations.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-sm">
                No campus facilities match "{searchQuery}".
                <p className="text-xs mt-1 text-slate-500">
                  Try searching by professor name, room number, or block.
                </p>
              </div>
            ) : (
              filteredLocations.map(loc => {
                const meta = getLocationMeta(loc);
                return (
                  <div
                    key={loc.id}
                    onClick={() => handleSelectLocation(loc, false)}
                    className="flex items-center justify-between p-2.5 hover:bg-blue-50/70 rounded-xl cursor-pointer transition-colors group"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <div className="mt-0.5 w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-slate-800 truncate group-hover:text-blue-900">
                            {loc.name}
                          </span>
                          <span className="px-1.5 py-0.2 rounded-sm bg-slate-100 text-slate-600 text-[10px] font-mono font-bold">
                            {loc.roomNumber}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 truncate mt-0.5">
                          {meta.buildingName} • {meta.floorName}
                        </p>
                        {loc.facultyInfo && (
                          <p className="text-[11px] text-blue-600 font-medium truncate mt-0.5">
                            {loc.facultyInfo.name} ({loc.facultyInfo.designation})
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-2">
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          handleSelectLocation(loc, true);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1 shadow-xs cursor-pointer"
                        title="Start turn-by-turn navigation"
                      >
                        <span>Go</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
