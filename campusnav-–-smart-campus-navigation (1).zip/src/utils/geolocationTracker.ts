export interface GeolocationCoordsUpdate {
  lat: number;
  lng: number;
  accuracy: number;
  heading: number | null;
  speed: number | null;
}

let watchId: number | null = null;

export function startTracking(
  onUpdate: (coords: GeolocationCoordsUpdate) => void,
  onError: (message: string) => void
): void {
  if (!('geolocation' in navigator)) {
    onError('Geolocation not supported on this device.');
    return;
  }

  if (watchId !== null) {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }

  watchId = navigator.geolocation.watchPosition(
    (pos) => {
      const { latitude, longitude, accuracy, heading, speed } = pos.coords;
      onUpdate({ lat: latitude, lng: longitude, accuracy, heading, speed });
    },
    (err) => {
      if (err.code === 1) onError('Location permission denied.');
      else if (err.code === 2) onError('Location unavailable.');
      else onError('Location request timed out.');
    },
    {
      enableHighAccuracy: true, // use GPS, not just wifi/cell
      maximumAge: 1000,
      timeout: 10000,
    }
  );
}

export function stopTracking(): void {
  if (watchId !== null) {
    navigator.geolocation.clearWatch(watchId);
    watchId = null;
  }
}

export function isTrackingActive(): boolean {
  return watchId !== null;
}
