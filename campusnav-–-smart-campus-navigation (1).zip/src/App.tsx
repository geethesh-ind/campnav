/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CampusProvider, useCampus } from './context/CampusContext';
import { Navbar } from './components/Navbar';
import { SearchBar } from './components/SearchBar';
import { CampusMap } from './components/CampusMap';
import { NavigationSheet } from './components/NavigationSheet';
import { DestinationCard } from './components/DestinationCard';
import { QRScannerModal } from './components/QRScannerModal';
import { PositioningModal } from './components/PositioningModal';
import { AdminDashboard } from './components/AdminDashboard';
import {
  MapPin,
  QrCode,
  ChevronRight,
  Sparkles,
  Building2,
  Layers,
} from 'lucide-react';

const MainScreenContent: React.FC = () => {
  const {
    buildings,
    floors,
    locations,
    activeBuildingId,
    activeFloorId,
    setSelectedDestination,
    startNavigation,
    setActiveBuildingId,
    setActiveFloorId,
    userPosition,
    isNavigating,
  } = useCampus();

  const [isQROpen, setIsQROpen] = useState(false);
  const [isPositioningOpen, setIsPositioningOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Popular campus shortcuts
  const popularPlaces = locations.filter(l => l.isPopular).slice(0, 6);

  const handleQuickGo = (loc: typeof locations[0]) => {
    setSelectedDestination(loc);
    setActiveBuildingId(loc.buildingId === 'outdoor' ? null : loc.buildingId);
    setActiveFloorId(loc.floorId);
    startNavigation(loc);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-800">
      {/* 1. Header Navbar */}
      <Navbar
        onOpenQRScanner={() => setIsQROpen(true)}
        onOpenPositioningModal={() => setIsPositioningOpen(true)}
        isAdminOpen={isAdminOpen}
        onToggleAdmin={() => setIsAdminOpen(prev => !prev)}
      />

      {/* 2. Main Interactive Map Area */}
      <main className="flex-1 flex flex-col max-w-7xl w-full mx-auto p-2 sm:p-4 gap-3 relative">
        {/* Floating Search Bar */}
        <SearchBar />

        {/* Block & Uploaded Floor Blueprint Quick Launcher */}
        {!isNavigating && (
          <div className="bg-white/95 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 border border-slate-200/90 shadow-2xs flex flex-col gap-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
                <Building2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Canara Engineering College Floor Plans</span>
              </div>

              <div className="flex items-center gap-2 text-[11px]">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 font-semibold">
                  <MapPin className="w-3 h-3" />
                  <span className="truncate max-w-[190px]">
                    At: {userPosition.confirmedLocationName || 'Campus Gate'}
                  </span>
                </span>
                <button
                  onClick={() => setIsQROpen(true)}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer transition-colors"
                >
                  <QrCode className="w-3 h-3 text-blue-600" />
                  <span>Set Start / QR</span>
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setActiveBuildingId(null)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                  !activeBuildingId || activeBuildingId === 'outdoor'
                    ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                Campus Overview
              </button>

              {buildings.map(b => {
                const bFloors = floors
                  .filter(f => f.buildingId === b.id && f.floorMapImage)
                  .sort((a, z) => a.floorNumber - z.floorNumber);
                const isBlockActive = activeBuildingId === b.id;

                return (
                  <div
                    key={b.id}
                    className={`flex items-center gap-1 rounded-lg border px-1.5 py-1 transition-all ${
                      isBlockActive
                        ? 'bg-blue-50/90 border-blue-300'
                        : 'bg-white border-slate-200'
                    }`}
                  >
                    <button
                      onClick={() => setActiveBuildingId(b.id)}
                      className="text-xs font-bold text-slate-800 hover:text-blue-700 px-1 cursor-pointer flex items-center gap-1"
                    >
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{ backgroundColor: b.color }}
                      />
                      <span>{b.code}</span>
                    </button>

                    {bFloors.map(f => {
                      const isFloorActive = activeFloorId === f.id;
                      return (
                        <button
                          key={f.id}
                          onClick={() => {
                            setActiveBuildingId(b.id);
                            setActiveFloorId(f.id);
                          }}
                          className={`px-1.5 py-0.5 rounded text-[11px] font-mono font-bold transition-colors cursor-pointer flex items-center gap-0.5 ${
                            isFloorActive
                              ? 'bg-blue-600 text-white shadow-2xs'
                              : 'bg-slate-100 hover:bg-blue-100 text-slate-600'
                          }`}
                          title={`${b.name} – ${f.floorName}`}
                        >
                          <Layers className="w-2.5 h-2.5" />
                          <span>{f.code}</span>
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Interactive Map */}
        <div className="relative w-full flex-1 min-h-[480px]">
          <CampusMap />
        </div>

        {/* Quick Popular Destinations Pill Tray (Visible when not actively navigating) */}
        {!isNavigating && (
          <div className="bg-white/90 backdrop-blur-md rounded-2xl p-3 border border-slate-200/90 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                <span>Frequently Visited Places</span>
              </span>
              <span className="text-[11px] text-slate-400">Tap to route</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
              {popularPlaces.map(place => (
                <button
                  key={place.id}
                  onClick={() => handleQuickGo(place)}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-blue-50/80 border border-slate-200/80 hover:border-blue-300 transition-all text-left flex flex-col justify-between group cursor-pointer shadow-2xs"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-[10px] font-bold text-blue-700 bg-blue-100/70 px-1 py-0.2 rounded">
                      {place.roomNumber}
                    </span>
                    <ChevronRight className="w-3 h-3 text-slate-400 group-hover:text-blue-600 transition-colors" />
                  </div>
                  <span className="text-xs font-bold text-slate-800 group-hover:text-blue-900 truncate">
                    {place.name}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* 3. Bottom Cards & Modals */}
      <DestinationCard />
      <NavigationSheet />

      {/* QR Scanner & Generator Modal */}
      <QRScannerModal isOpen={isQROpen} onClose={() => setIsQROpen(false)} />

      {/* Positioning Infrastructure Modal */}
      <PositioningModal isOpen={isPositioningOpen} onClose={() => setIsPositioningOpen(false)} />

      {/* Admin Dashboard */}
      {isAdminOpen && <AdminDashboard onClose={() => setIsAdminOpen(false)} />}
    </div>
  );
};

export default function App() {
  return (
    <CampusProvider>
      <MainScreenContent />
    </CampusProvider>
  );
}

