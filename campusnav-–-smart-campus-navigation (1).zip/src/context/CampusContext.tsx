import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  Building,
  Floor,
  CampusLocation,
  NavigationNode,
  NavigationConnection,
  QRCheckpoint,
  BLEBeacon,
  UserPosition,
  CalculatedRoute,
  RoutingPreference,
  WrongDirectionStatus,
  PositioningMethod,
} from '../types/campus';
import {
  CampusDatabase,
  getDefaultCampusData,
} from '../data/initialCampusData';
import {
  findOptimalPath,
  generateNavigationSteps,
  detectWrongDirection,
} from '../utils/navigationEngine';
import { soundEffects } from '../utils/audioAlert';
import {
  startTracking,
  stopTracking,
  GeolocationCoordsUpdate,
} from '../utils/geolocationTracker';

const STORAGE_KEY = 'campusnav_db_v3_cec';

interface CampusContextType {
  // Database
  buildings: Building[];
  floors: Floor[];
  locations: CampusLocation[];
  nodes: NavigationNode[];
  connections: NavigationConnection[];
  qrCheckpoints: QRCheckpoint[];
  beacons: BLEBeacon[];

  // View state
  activeBuildingId: string | null;
  activeFloorId: string | null;
  selectedDestination: CampusLocation | null;
  startLocation: CampusLocation | null;
  routingPreference: RoutingPreference;
  searchQuery: string;

  // Navigation state
  isNavigating: boolean;
  activeRoute: CalculatedRoute | null;
  currentStepIndex: number;
  userPosition: UserPosition;
  wrongDirectionStatus: WrongDirectionStatus | null;
  isSimulatingWalk: boolean;
  simulationSpeed: number;

  // Positioning details
  positioningMethod: PositioningMethod;
  gpsTrackingActive: boolean;
  gpsError: string | null;
  liveGpsCoords: GeolocationCoordsUpdate | null;

  // Actions
  setActiveBuildingId: (id: string | null) => void;
  setActiveFloorId: (id: string | null) => void;
  setSelectedDestination: (loc: CampusLocation | null) => void;
  setStartLocation: (loc: CampusLocation | null) => void;
  setRoutingPreference: (pref: RoutingPreference) => void;
  setSearchQuery: (query: string) => void;

  startNavigation: (destination?: CampusLocation, startLoc?: CampusLocation) => void;
  stopNavigation: () => void;
  recalculateRoute: () => void;
  stepForward: () => void;
  stepBackward: () => void;
  toggleSimulation: () => void;
  setSimulationSpeed: (speed: number) => void;
  simulateWrongTurn: () => void;
  setUserPositionManual: (pos: Partial<UserPosition>) => void;
  confirmLocationByQR: (qrCode: string) => { success: boolean; message: string; checkpoint?: QRCheckpoint };
  simulateBLEScan: () => void;
  requestRealGPS: () => Promise<boolean>;
  startLiveGPSTracking: () => void;
  stopLiveGPSTracking: () => void;

  // Admin mutation actions
  addBuilding: (b: Building) => void;
  updateBuilding: (b: Building) => void;
  deleteBuilding: (id: string) => void;
  addFloor: (f: Floor) => void;
  updateFloor: (f: Floor) => void;
  deleteFloor: (id: string) => void;
  addLocation: (loc: CampusLocation) => void;
  updateLocation: (loc: CampusLocation) => void;
  deleteLocation: (id: string) => void;
  addNode: (node: NavigationNode) => void;
  updateNode: (node: NavigationNode) => void;
  deleteNode: (id: string) => void;
  addConnection: (conn: NavigationConnection) => void;
  deleteConnection: (id: string) => void;
  addQRCheckpoint: (qr: QRCheckpoint) => void;
  deleteQRCheckpoint: (id: string) => void;
  resetToDefaultData: () => void;
  importDatabaseJson: (json: string) => boolean;
  exportDatabaseJson: () => string;
}

const CampusContext = createContext<CampusContextType | undefined>(undefined);

export const CampusProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Initial State from localStorage or default
  const [database, setDatabase] = useState<CampusDatabase>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.buildings && parsed.locations && parsed.nodes) {
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return getDefaultCampusData();
  });

  // Save to localStorage when database changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(database));
    } catch {
      // Storage quota or disabled
    }
  }, [database]);

  // View state
  const [activeBuildingId, setActiveBuildingIdState] = useState<string | null>(null);
  const [activeFloorId, setActiveFloorIdState] = useState<string | null>(null);
  const [selectedDestination, setSelectedDestination] = useState<CampusLocation | null>(null);
  const [startLocation, setStartLocation] = useState<CampusLocation | null>(null);
  const [routingPreference, setRoutingPreference] = useState<RoutingPreference>('shortest');
  const [searchQuery, setSearchQuery] = useState('');

  // Initial user position: Main Campus Entrance Gate (Outdoor)
  const [userPosition, setUserPosition] = useState<UserPosition>({
    x: 500,
    y: 560,
    buildingId: 'outdoor',
    floorId: 'outdoor',
    heading: 0,
    method: 'gps',
    accuracyMeters: 8,
    lastUpdated: Date.now(),
    confirmedLocationName: 'Canara Engineering College Main Gate',
  });

  // Navigation State
  const [isNavigating, setIsNavigating] = useState(false);
  const [activeRoute, setActiveRoute] = useState<CalculatedRoute | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [wrongDirectionStatus, setWrongDirectionStatus] = useState<WrongDirectionStatus | null>(null);
  const [isSimulatingWalk, setIsSimulatingWalk] = useState(false);
  const [simulationSpeed, setSimulationSpeed] = useState(1);
  const [gpsTrackingActive, setGpsTrackingActive] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [liveGpsCoords, setLiveGpsCoords] = useState<GeolocationCoordsUpdate | null>(null);

  const simulationTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      stopTracking();
    };
  }, []);

  // Helper to switch active building & floor seamlessly
  const setActiveBuildingId = useCallback((bId: string | null) => {
    setActiveBuildingIdState(bId);
    if (!bId || bId === 'outdoor') {
      setActiveFloorIdState('outdoor');
    } else {
      const b = database.buildings.find(item => item.id === bId);
      if (b && b.floorIds.length > 0) {
        // default to Ground Floor if available, otherwise first floor
        const ground = database.floors.find(f => f.buildingId === bId && f.floorNumber === 0);
        setActiveFloorIdState(ground ? ground.id : b.floorIds[0]);
      }
    }
  }, [database.buildings, database.floors]);

  const setActiveFloorId = useCallback((fId: string | null) => {
    setActiveFloorIdState(fId);
    if (fId && fId !== 'outdoor') {
      const floor = database.floors.find(f => f.id === fId);
      if (floor) {
        setActiveBuildingIdState(floor.buildingId);
      }
    }
  }, [database.floors]);

  // Find nearest node to a user position
  const getNearestNodeId = useCallback((pos: { x: number; y: number; buildingId: string; floorId: string }): string => {
    let closestNode = database.nodes[0];
    let minDistance = Infinity;

    // First try matching floor and building
    const sameFloorNodes = database.nodes.filter(
      n => n.floorId === pos.floorId && n.buildingId === pos.buildingId
    );

    const candidates = sameFloorNodes.length > 0 ? sameFloorNodes : database.nodes;

    for (const node of candidates) {
      const d = Math.hypot(node.x - pos.x, node.y - pos.y);
      if (d < minDistance) {
        minDistance = d;
        closestNode = node;
      }
    }

    return closestNode.id;
  }, [database.nodes]);

  // Calculate Route function
  const computeRoute = useCallback((
    destination: CampusLocation,
    startLoc: CampusLocation | null,
    pos: UserPosition,
    pref: RoutingPreference
  ): CalculatedRoute | null => {
    const startNodeId = startLoc ? startLoc.associatedNodeId : getNearestNodeId(pos);
    const destNodeId = destination.associatedNodeId;

    const pathResult = findOptimalPath(
      startNodeId,
      destNodeId,
      database.nodes,
      database.connections,
      pref
    );

    if (!pathResult) return null;

    const pathNodes = pathResult.pathNodeIds.map(id => database.nodes.find(n => n.id === id)!);
    const steps = generateNavigationSteps(
      pathNodes,
      database.connections,
      database.floors,
      database.buildings,
      destination.name
    );

    const estMinutes = Math.max(1, Math.round(pathResult.totalDistanceMeters / 60));

    return {
      id: `route_${Date.now()}`,
      totalDistanceMeters: pathResult.totalDistanceMeters,
      estimatedTimeMinutes: estMinutes,
      steps,
      nodePath: pathNodes,
      connectionIds: pathResult.connectionIds,
      preference: pref,
      startLocationName: startLoc ? startLoc.name : pos.confirmedLocationName || 'Current Location',
      destinationLocationName: destination.name,
      destinationLocation: destination,
      startNodeId,
      destinationNodeId: destNodeId,
    };
  }, [database.connections, database.floors, database.buildings, database.nodes, getNearestNodeId]);

  // Start Navigation
  const startNavigation = useCallback((
    dest?: CampusLocation,
    start?: CampusLocation
  ) => {
    const targetDest = dest || selectedDestination;
    if (!targetDest) return;

    const explicitStart = start || startLocation;
    const route = computeRoute(targetDest, explicitStart, userPosition, routingPreference);
    if (!route) {
      alert('Could not find a walkable path with the selected preferences.');
      return;
    }

    setActiveRoute(route);
    setCurrentStepIndex(0);
    setIsNavigating(true);
    setWrongDirectionStatus(null);
    setSelectedDestination(targetDest);

    // Auto switch map view to current route start floor/building
    if (route.nodePath.length > 0) {
      const first = route.nodePath[0];
      if (explicitStart) {
        setUserPosition(prev => ({
          ...prev,
          x: first.x,
          y: first.y,
          buildingId: first.buildingId,
          floorId: first.floorId,
          method: 'manual',
          accuracyMeters: 1,
          lastUpdated: Date.now(),
          confirmedLocationName: explicitStart.name,
        }));
      }
      setActiveBuildingIdState(first.buildingId === 'outdoor' ? null : first.buildingId);
      setActiveFloorIdState(first.floorId);
    }
  }, [selectedDestination, startLocation, userPosition, routingPreference, computeRoute]);

  // Automatically recalculate active route if user changes routing preference (Shortest / Fewer Stairs / Wheelchair)
  useEffect(() => {
    if (!isNavigating || !activeRoute) return;
    if (activeRoute.preference === routingPreference) return;
    const updated = computeRoute(
      activeRoute.destinationLocation,
      null,
      userPosition,
      routingPreference
    );
    if (updated) {
      setActiveRoute(updated);
      setCurrentStepIndex(0);
      setWrongDirectionStatus(null);
    }
  }, [routingPreference, isNavigating, activeRoute, computeRoute, userPosition]);

  // Stop Navigation
  const stopNavigation = useCallback(() => {
    setIsNavigating(false);
    setActiveRoute(null);
    setCurrentStepIndex(0);
    setWrongDirectionStatus(null);
    setIsSimulatingWalk(false);
    if (simulationTimerRef.current) {
      clearInterval(simulationTimerRef.current);
      simulationTimerRef.current = null;
    }
  }, []);

  // Recalculate Route (used after wrong turn or manual request)
  const recalculateRoute = useCallback(() => {
    if (!activeRoute || !activeRoute.destinationLocation) return;
    soundEffects.playRecalculatingChime();

    const newRoute = computeRoute(
      activeRoute.destinationLocation,
      null, // from current user position
      userPosition,
      routingPreference
    );

    if (newRoute) {
      setActiveRoute(newRoute);
      setCurrentStepIndex(0);
      setWrongDirectionStatus(null);
      // Align view to user's updated position
      setActiveBuildingIdState(userPosition.buildingId === 'outdoor' ? null : userPosition.buildingId);
      setActiveFloorIdState(userPosition.floorId);
    }
  }, [activeRoute, computeRoute, userPosition, routingPreference]);

  // Step Forward in Navigation
  const stepForward = useCallback(() => {
    if (!activeRoute) return;

    if (currentStepIndex >= activeRoute.steps.length - 1) {
      // Arrived!
      soundEffects.playArrivalChime();
      return;
    }

    const nextIndex = currentStepIndex + 1;
    setCurrentStepIndex(nextIndex);

    // Move user position to the next node
    const nextNode = activeRoute.nodePath[Math.min(nextIndex, activeRoute.nodePath.length - 1)];
    if (nextNode) {
      setUserPosition(prev => ({
        ...prev,
        x: nextNode.x,
        y: nextNode.y,
        buildingId: nextNode.buildingId,
        floorId: nextNode.floorId,
        lastUpdated: Date.now(),
        confirmedLocationName: nextNode.label || prev.confirmedLocationName,
      }));

      // Auto update active view if floor changed
      setActiveBuildingIdState(nextNode.buildingId === 'outdoor' ? null : nextNode.buildingId);
      setActiveFloorIdState(nextNode.floorId);
    }

    // Check wrong direction
    if (nextNode) {
      const check = detectWrongDirection(
        { x: nextNode.x, y: nextNode.y, floorId: nextNode.floorId, buildingId: nextNode.buildingId },
        activeRoute.nodePath,
        nextIndex
      );
      setWrongDirectionStatus(check.isWrongDirection ? check : null);
    }
  }, [activeRoute, currentStepIndex]);

  // Step Backward
  const stepBackward = useCallback(() => {
    if (!activeRoute || currentStepIndex <= 0) return;
    const prevIndex = currentStepIndex - 1;
    setCurrentStepIndex(prevIndex);
    const prevNode = activeRoute.nodePath[prevIndex];
    if (prevNode) {
      setUserPosition(prev => ({
        ...prev,
        x: prevNode.x,
        y: prevNode.y,
        buildingId: prevNode.buildingId,
        floorId: prevNode.floorId,
        lastUpdated: Date.now(),
      }));
      setActiveBuildingIdState(prevNode.buildingId === 'outdoor' ? null : prevNode.buildingId);
      setActiveFloorIdState(prevNode.floorId);
    }
  }, [activeRoute, currentStepIndex]);

  // Simulate Wrong Turn to demonstrate Wrong-Direction Detection
  const simulateWrongTurn = useCallback(() => {
    if (!isNavigating || !activeRoute) return;

    // Displace user significantly from current path node
    setUserPosition(prev => {
      const wrongPos: UserPosition = {
        ...prev,
        x: prev.x + 85, // 85 pixels / meters off corridor
        y: prev.y + 70,
        lastUpdated: Date.now(),
        confirmedLocationName: 'Off Route Corridor',
      };

      const check = detectWrongDirection(
        wrongPos,
        activeRoute.nodePath,
        currentStepIndex,
        15
      );

      if (check.isWrongDirection) {
        soundEffects.playWrongDirectionAlert();
        setWrongDirectionStatus(check);

        // Auto-recalculate after 2.5 seconds like real Google Maps
        setTimeout(() => {
          recalculateRoute();
        }, 2200);
      }

      return wrongPos;
    });
  }, [isNavigating, activeRoute, currentStepIndex, recalculateRoute]);

  // Continuous Walk Simulation
  const toggleSimulation = useCallback(() => {
    setIsSimulatingWalk(prev => !prev);
  }, []);

  useEffect(() => {
    if (isSimulatingWalk && isNavigating && activeRoute) {
      const intervalMs = Math.max(500, Math.round(2000 / simulationSpeed));
      simulationTimerRef.current = window.setInterval(() => {
        setCurrentStepIndex(prevIdx => {
          if (prevIdx >= activeRoute.steps.length - 1) {
            setIsSimulatingWalk(false);
            soundEffects.playArrivalChime();
            return prevIdx;
          }
          const nextIdx = prevIdx + 1;
          const nextNode = activeRoute.nodePath[Math.min(nextIdx, activeRoute.nodePath.length - 1)];
          if (nextNode) {
            setUserPosition(p => ({
              ...p,
              x: nextNode.x,
              y: nextNode.y,
              buildingId: nextNode.buildingId,
              floorId: nextNode.floorId,
              lastUpdated: Date.now(),
              confirmedLocationName: nextNode.label || p.confirmedLocationName,
            }));
            setActiveBuildingIdState(nextNode.buildingId === 'outdoor' ? null : nextNode.buildingId);
            setActiveFloorIdState(nextNode.floorId);
          }
          return nextIdx;
        });
      }, intervalMs);
    } else {
      if (simulationTimerRef.current) {
        clearInterval(simulationTimerRef.current);
        simulationTimerRef.current = null;
      }
    }

    return () => {
      if (simulationTimerRef.current) {
        clearInterval(simulationTimerRef.current);
        simulationTimerRef.current = null;
      }
    };
  }, [isSimulatingWalk, isNavigating, activeRoute, simulationSpeed]);

  // Set User Position Manually (e.g. clicking on map)
  const setUserPositionManual = useCallback((pos: Partial<UserPosition>) => {
    setUserPosition(prev => {
      const updated = {
        ...prev,
        ...pos,
        lastUpdated: Date.now(),
      };

      if (isNavigating && activeRoute) {
        const check = detectWrongDirection(
          { x: updated.x, y: updated.y, floorId: updated.floorId, buildingId: updated.buildingId },
          activeRoute.nodePath,
          currentStepIndex
        );
        if (check.isWrongDirection) {
          soundEffects.playWrongDirectionAlert();
          setWrongDirectionStatus(check);
        } else {
          setWrongDirectionStatus(null);
        }
      }

      return updated;
    });
  }, [isNavigating, activeRoute, currentStepIndex]);

  // QR-Based Exact Checkpoint Location Confirmation
  const confirmLocationByQR = useCallback((qrCode: string): { success: boolean; message: string; checkpoint?: QRCheckpoint } => {
    const checkpoint = database.qrCheckpoints.find(q => q.code === qrCode);
    if (!checkpoint) {
      return { success: false, message: 'Invalid or unknown QR code. Please scan an authorized CampusNav checkpoint.' };
    }

    setUserPosition({
      x: checkpoint.coordinates.x,
      y: checkpoint.coordinates.y,
      buildingId: checkpoint.buildingId,
      floorId: checkpoint.floorId,
      heading: 0,
      method: 'qr',
      accuracyMeters: 0.5, // 100% precise
      lastUpdated: Date.now(),
      confirmedLocationName: checkpoint.label,
    });

    setActiveBuildingIdState(checkpoint.buildingId === 'outdoor' ? null : checkpoint.buildingId);
    setActiveFloorIdState(checkpoint.floorId);

    // If currently navigating, check if route matches or recalculate
    if (isNavigating && activeRoute) {
      const check = detectWrongDirection(
        { x: checkpoint.coordinates.x, y: checkpoint.coordinates.y, floorId: checkpoint.floorId, buildingId: checkpoint.buildingId },
        activeRoute.nodePath,
        currentStepIndex
      );

      if (check.isWrongDirection) {
        soundEffects.playWrongDirectionAlert();
        setWrongDirectionStatus(check);
        setTimeout(() => recalculateRoute(), 1200);
      } else {
        setWrongDirectionStatus(null);
      }
    }

    return {
      success: true,
      message: `Verified Location: ${checkpoint.label}`,
      checkpoint,
    };
  }, [database.qrCheckpoints, isNavigating, activeRoute, currentStepIndex, recalculateRoute]);

  // Simulate BLE Beacon Proximity Detection
  const simulateBLEScan = useCallback(() => {
    if (database.beacons.length === 0) return;
    // Pick nearest beacon to active building or first beacon
    const targetBeacon = database.beacons.find(b => b.buildingId === activeBuildingId) || database.beacons[0];
    const node = database.nodes.find(n => n.id === targetBeacon.nodeId);
    if (!node) return;

    setUserPosition({
      x: node.x,
      y: node.y,
      buildingId: targetBeacon.buildingId,
      floorId: targetBeacon.floorId,
      heading: 90,
      method: 'ble',
      accuracyMeters: 2.5,
      lastUpdated: Date.now(),
      confirmedLocationName: `BLE: ${targetBeacon.label}`,
    });

    setActiveBuildingIdState(targetBeacon.buildingId === 'outdoor' ? null : targetBeacon.buildingId);
    setActiveFloorIdState(targetBeacon.floorId);
  }, [database.beacons, database.nodes, activeBuildingId]);

  // Outdoor Real GPS integration (one-shot + continuous watchPosition)
  const applyGpsCoordsUpdate = useCallback((coords: GeolocationCoordsUpdate) => {
    setLiveGpsCoords(coords);
    setGpsError(null);

    // Canara Engineering College Benjanapadavu approximate campus center
    const CAMPUS_LAT = 12.8986;
    const CAMPUS_LNG = 74.9854;
    const dLat = coords.lat - CAMPUS_LAT;
    const dLng = coords.lng - CAMPUS_LNG;
    const isNearCampus = Math.abs(dLat) < 0.004 && Math.abs(dLng) < 0.004;

    setUserPosition(prev => {
      let nextX = prev.buildingId === 'outdoor' ? prev.x : 500;
      let nextY = prev.buildingId === 'outdoor' ? prev.y : 560;

      if (isNearCampus) {
        // Project local campus offset onto 1000x650 outdoor canvas
        nextX = Math.max(120, Math.min(880, Math.round(500 + dLng * 120000)));
        nextY = Math.max(80, Math.min(580, Math.round(330 - dLat * 120000)));
      }

      const acc = Math.round(coords.accuracy || 10);
      return {
        ...prev,
        x: nextX,
        y: nextY,
        buildingId: 'outdoor',
        floorId: 'outdoor',
        heading:
          coords.heading !== null && !Number.isNaN(coords.heading)
            ? Math.round(coords.heading)
            : prev.heading,
        method: 'gps',
        accuracyMeters: acc,
        lastUpdated: Date.now(),
        confirmedLocationName: `Live GPS (${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}) · ±${acc}m`,
      };
    });
  }, []);

  const stopLiveGPSTracking = useCallback(() => {
    stopTracking();
    setGpsTrackingActive(false);
  }, []);

  const startLiveGPSTracking = useCallback(() => {
    setGpsError(null);
    setGpsTrackingActive(true);
    startTracking(
      (coords) => {
        applyGpsCoordsUpdate(coords);
      },
      (errMsg) => {
        setGpsError(errMsg);
        setGpsTrackingActive(false);
        stopTracking();
      }
    );
  }, [applyGpsCoordsUpdate]);

  const requestRealGPS = useCallback(async (): Promise<boolean> => {
    if (!('geolocation' in navigator)) {
      setGpsError('Geolocation not supported on this device.');
      return false;
    }

    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          applyGpsCoordsUpdate({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy,
            heading: pos.coords.heading,
            speed: pos.coords.speed,
          });
          resolve(true);
        },
        (err) => {
          if (err.code === 1) setGpsError('Location permission denied.');
          else if (err.code === 2) setGpsError('Location unavailable.');
          else setGpsError('Location request timed out.');
          resolve(false);
        },
        { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
      );
    });
  }, [applyGpsCoordsUpdate]);

  // Admin database mutation functions
  const addBuilding = useCallback((b: Building) => {
    setDatabase(prev => ({ ...prev, buildings: [...prev.buildings, b] }));
  }, []);

  const updateBuilding = useCallback((b: Building) => {
    setDatabase(prev => ({
      ...prev,
      buildings: prev.buildings.map(item => (item.id === b.id ? b : item)),
    }));
  }, []);

  const deleteBuilding = useCallback((id: string) => {
    setDatabase(prev => ({
      ...prev,
      buildings: prev.buildings.filter(b => b.id !== id),
      floors: prev.floors.filter(f => f.buildingId !== id),
      locations: prev.locations.filter(l => l.buildingId !== id),
      nodes: prev.nodes.filter(n => n.buildingId !== id),
    }));
  }, []);

  const addFloor = useCallback((f: Floor) => {
    setDatabase(prev => ({
      ...prev,
      floors: [...prev.floors, f],
      buildings: prev.buildings.map(b => (b.id === f.buildingId ? { ...b, floorIds: [...b.floorIds, f.id] } : b)),
    }));
  }, []);

  const updateFloor = useCallback((f: Floor) => {
    setDatabase(prev => ({
      ...prev,
      floors: prev.floors.map(item => (item.id === f.id ? f : item)),
    }));
  }, []);

  const deleteFloor = useCallback((id: string) => {
    setDatabase(prev => ({
      ...prev,
      floors: prev.floors.filter(f => f.id !== id),
      locations: prev.locations.filter(l => l.floorId !== id),
      nodes: prev.nodes.filter(n => n.floorId !== id),
    }));
  }, []);

  const addLocation = useCallback((loc: CampusLocation) => {
    setDatabase(prev => ({ ...prev, locations: [...prev.locations, loc] }));
  }, []);

  const updateLocation = useCallback((loc: CampusLocation) => {
    setDatabase(prev => ({
      ...prev,
      locations: prev.locations.map(item => (item.id === loc.id ? loc : item)),
    }));
  }, []);

  const deleteLocation = useCallback((id: string) => {
    setDatabase(prev => ({
      ...prev,
      locations: prev.locations.filter(item => item.id !== id),
    }));
  }, []);

  const addNode = useCallback((node: NavigationNode) => {
    setDatabase(prev => ({ ...prev, nodes: [...prev.nodes, node] }));
  }, []);

  const updateNode = useCallback((node: NavigationNode) => {
    setDatabase(prev => ({
      ...prev,
      nodes: prev.nodes.map(n => (n.id === node.id ? node : n)),
    }));
  }, []);

  const deleteNode = useCallback((id: string) => {
    setDatabase(prev => ({
      ...prev,
      nodes: prev.nodes.filter(n => n.id !== id),
      connections: prev.connections.filter(c => c.startNodeId !== id && c.endNodeId !== id),
    }));
  }, []);

  const addConnection = useCallback((conn: NavigationConnection) => {
    setDatabase(prev => ({ ...prev, connections: [...prev.connections, conn] }));
  }, []);

  const deleteConnection = useCallback((id: string) => {
    setDatabase(prev => ({
      ...prev,
      connections: prev.connections.filter(c => c.id !== id),
    }));
  }, []);

  const addQRCheckpoint = useCallback((qr: QRCheckpoint) => {
    setDatabase(prev => ({ ...prev, qrCheckpoints: [...prev.qrCheckpoints, qr] }));
  }, []);

  const deleteQRCheckpoint = useCallback((id: string) => {
    setDatabase(prev => ({
      ...prev,
      qrCheckpoints: prev.qrCheckpoints.filter(q => q.id !== id),
    }));
  }, []);

  const resetToDefaultData = useCallback(() => {
    const defaultData = getDefaultCampusData();
    setDatabase(defaultData);
    localStorage.removeItem(STORAGE_KEY);
    stopNavigation();
  }, [stopNavigation]);

  const importDatabaseJson = useCallback((json: string): boolean => {
    try {
      const data = JSON.parse(json);
      if (data.buildings && data.locations && data.nodes && data.connections) {
        setDatabase(data);
        return true;
      }
    } catch {
      // Invalid
    }
    return false;
  }, []);

  const exportDatabaseJson = useCallback((): string => {
    return JSON.stringify(database, null, 2);
  }, [database]);

  return (
    <CampusContext.Provider
      value={{
        buildings: database.buildings,
        floors: database.floors,
        locations: database.locations,
        nodes: database.nodes,
        connections: database.connections,
        qrCheckpoints: database.qrCheckpoints,
        beacons: database.beacons,

        activeBuildingId,
        activeFloorId,
        selectedDestination,
        startLocation,
        routingPreference,
        searchQuery,

        isNavigating,
        activeRoute,
        currentStepIndex,
        userPosition,
        wrongDirectionStatus,
        isSimulatingWalk,
        simulationSpeed,

        positioningMethod: userPosition.method,
        gpsTrackingActive,
        gpsError,
        liveGpsCoords,

        setActiveBuildingId,
        setActiveFloorId,
        setSelectedDestination,
        setStartLocation,
        setRoutingPreference,
        setSearchQuery,

        startNavigation,
        stopNavigation,
        recalculateRoute,
        stepForward,
        stepBackward,
        toggleSimulation,
        setSimulationSpeed,
        simulateWrongTurn,
        setUserPositionManual,
        confirmLocationByQR,
        simulateBLEScan,
        requestRealGPS,
        startLiveGPSTracking,
        stopLiveGPSTracking,

        addBuilding,
        updateBuilding,
        deleteBuilding,
        addFloor,
        updateFloor,
        deleteFloor,
        addLocation,
        updateLocation,
        deleteLocation,
        addNode,
        updateNode,
        deleteNode,
        addConnection,
        deleteConnection,
        addQRCheckpoint,
        deleteQRCheckpoint,
        resetToDefaultData,
        importDatabaseJson,
        exportDatabaseJson,
      }}
    >
      {children}
    </CampusContext.Provider>
  );
};

export const useCampus = (): CampusContextType => {
  const context = useContext(CampusContext);
  if (!context) {
    throw new Error('useCampus must be used within a CampusProvider');
  }
  return context;
};
